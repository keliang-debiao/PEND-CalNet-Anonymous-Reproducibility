# PEND-CalNet Anonymous Reproducibility Package

This repository accompanies the manuscript **Cross-Corpus Calibrated Tibetan Dialect Identification through Phonological Evidence Fusion and Nuisance Disentanglement**. It provides the complete source pipeline for data auditing, speaker-grouped development, PEND-CalNet training, source-only calibration, frozen external evaluation, robustness analysis, paired inference, and manuscript table generation.

## Scope

The package implements:

- TIBMD@MUC development with five speaker-grouped outer folds;
- Tibetan Greetings SLR149 and TibSpeech-3D Finance frozen external evaluation;
- XLS-R-300M with LoRA in transformer blocks 13-24;
- counterfactual phonological evidence fusion;
- quality-aware attentive statistics pooling;
- conditional speaker and prompt nuisance disentanglement;
- cross-speaker supervised contrastive learning;
- margin-quality adaptive calibration;
- baseline, ablation, calibration, robustness, statistical, interpretability, and efficiency analyses.

No speech recordings are redistributed. Dataset acquisition remains governed by the original providers and licenses.

## Repository map

| Path | Purpose |
|---|---|
| `configs/` | Dataset, model, optimization, and variant settings |
| `src/pend_calnet/` | Data, feature, model, loss, calibration, metric, and statistical code |
| `scripts/` | Command-line entry points for the complete study workflow |
| `manifests/` | Manifest schema and generated split destination |
| `results/reference_records/` | Manuscript-aligned target matrices used for reproduction checks |
| `logs/` | Manuscript-aligned reference run records |
| `tests/` | Shape, loss, calibration, and metric tests |

`RESULTS_PROVENANCE.md` defines the separation between manuscript-aligned reference records and locally generated evidence. `BASELINE_PROTOCOL.md` specifies the common split, calibration, and comparison rules for all comparator families.
`MODEL_SPECIFICATION.md` fixes tensor shapes, feature order, training-only branches, and the frozen inference path.

## Environment

The recorded software target is Python 3.11.9, PyTorch 2.4.1, torchaudio 2.4.1, transformers 4.46.3, and CUDA 12.1. Create the environment with either route below.

```bash
conda env create -f environment.yml
conda activate pend-calnet
```

or

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
```

## Data placement

Download the three public corpora from the provider pages listed in `DATA_ACCESS.md`. Place the extracted releases outside this repository and set:

```bash
export TIBMD_ROOT=/absolute/path/to/SLR124
export SLR149_ROOT=/absolute/path/to/SLR149
export TIBSPEECH3D_ROOT=/absolute/path/to/TibSpeech-3D
```

Build auditable manifests without copying audio into the repository:

```bash
python scripts/build_manifest.py --dataset configs/datasets/tibmd.yaml --root "$TIBMD_ROOT" --output manifests/tibmd.csv
python scripts/build_manifest.py --dataset configs/datasets/slr149.yaml --root "$SLR149_ROOT" --output manifests/slr149.csv
python scripts/build_manifest.py --dataset configs/datasets/finance.yaml --root "$TIBSPEECH3D_ROOT" --output manifests/finance.csv
python scripts/audit_data.py --config configs/pend_calnet.yaml
python scripts/build_folds.py --config configs/pend_calnet.yaml
```

## Development and frozen external evaluation

Run one outer fold and one seed:

```bash
python scripts/train_cv.py --config configs/pend_calnet.yaml --fold 1 --seed 2026
```

Run nested source-only selection for one fold:

```bash
python scripts/search_hyperparameters.py --config configs/pend_calnet.yaml --fold 1
```

Run the complete five-fold, three-seed workflow:

```bash
bash scripts/run_full_pipeline.sh
```

The final source configuration is formed from the five fold-winning configurations by the source-only consensus rule in the manuscript. External labels are not read during preprocessing, fitting, calibration, threshold selection, or configuration aggregation.

## Comparator and component analyses

The following commands use the same fold assignments as PEND-CalNet:

```bash
python scripts/run_baselines.py --config configs/pend_calnet.yaml --model xlsr_attentive --fold 1 --seed 2026
python scripts/run_ablations.py --config configs/pend_calnet.yaml --fold 1 --seed 2026
python scripts/run_statistics.py --candidate artifacts/analysis/ensemble_predictions/fold_1.csv --comparator xlsr=artifacts/baselines/xlsr_attentive/fold_1/predictions.csv
```

Allowed baseline identifiers are recorded in `configs/baselines.yaml`. Traditional models use fold-fitted eGeMAPSv02 summaries; neural and foundation baselines use the same waveform windows, source partitions, early-stopping rule, and source-only temperature fitting.

## Analysis products

After prediction files have been generated, run:

```bash
python scripts/run_analyses.py --config configs/pend_calnet.yaml
python scripts/build_report_assets.py --config configs/pend_calnet.yaml
```

Generated tables, figures, checksums, and metric files are written beneath `artifacts/`. The immutable target matrices under `results/reference_records/` are manuscript-aligned reference records. They are not a substitute for prediction files generated on the local machine.

Method and result graphics can be regenerated with:

```bash
python scripts/build_method_figures.py
python scripts/build_report_assets.py --config configs/pend_calnet.yaml --source reference
```

After the public corpora have been processed, select `--source reproduced` only when the complete corresponding analysis tables exist beneath `artifacts/analysis/`.

## Verification

```bash
python scripts/verify_package.py
pytest -q
```

The verification command checks configuration integrity, reference-matrix arithmetic, fold means and sample SDs, path hygiene, and the absence of author-identifying metadata. Unit tests require the pinned research environment because they exercise PyTorch modules.

## Anonymous review

The repository contains no author names, affiliations, email addresses, local account names, or private storage paths. See `ANONYMITY.md` for the release checklist.

