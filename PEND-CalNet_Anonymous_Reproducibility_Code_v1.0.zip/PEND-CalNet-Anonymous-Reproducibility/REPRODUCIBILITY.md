# Reproduction Protocol

## Fixed protocol

1. Audit each release independently and store decoded-audio SHA-256 values.
2. Reconstruct corpus-specific speaker and prompt groups from released metadata.
3. Assign TIBMD@MUC speakers to five immutable outer folds.
4. Within each outer-training partition, reserve disjoint speaker groups for inner validation and source calibration.
5. Run 30 multivariate TPE trials with the fold-specific sampler seed.
6. Fit seeds 2026, 2027, and 2028 with the selected fold configuration.
7. Fit MQAC only on source-calibration speakers after freezing the classifier.
8. Average calibrated probabilities across seeds before calculating each held-out fold metric.
9. Aggregate the five fold-winning configurations using the source-only consensus rule.
10. Refit the final source models and evaluate SLR149 and Finance without target adaptation.
11. Run the prespecified robustness, calibration, paired-inference, interpretability, and efficiency analyses.

## Configuration consensus

For each searched parameter, retain the modal candidate among the five fold winners. Resolve a frequency tie by better mean inner-validation rank and then by fewer trainable parameters. The external corpora are not accessed during this aggregation.

## Randomness control

- Model seeds: 2026, 2027, 2028
- Fold search seeds: 12027, 12028, 12029, 12030, 12031
- Split grouping unit: released or reconstructed speaker identifier
- Probability aggregation: arithmetic mean across the three calibrated seed vectors
- Noise seed: SHA-256 of `filename|condition|severity|2026`

## Required retained artifacts

- audited manifests and decoded-audio hashes;
- immutable outer-fold and source-split assignments;
- resolved configuration for each fold;
- model configuration hash and checkpoint hash;
- selected epoch and calibration parameters;
- prediction-level logits and calibrated probabilities;
- bootstrap and permutation indices;
- generated metric tables and figure source arrays.

## Reference-record status

Files in `results/reference_records/` and `logs/` encode the values reported in the manuscript and the expected workflow sequence. Each record carries `execution_verified=false`. Local reproduction must replace that field with machine-derived provenance and preserve the original reference files for comparison.

