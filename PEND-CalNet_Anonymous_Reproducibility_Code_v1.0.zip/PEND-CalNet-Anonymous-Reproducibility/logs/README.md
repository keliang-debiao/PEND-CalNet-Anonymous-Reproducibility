# Reference run records

These files encode the expected event order, configuration identifiers, stopping behavior, and manuscript metrics. They are provided to support implementation checks before access to the public audio releases is configured.

Every file declares `record_type=manuscript_reference` and `execution_verified=false`. Therefore, these records must not be represented as machine-generated evidence. A completed reproduction writes separate logs beneath `artifacts/` with environment, checkpoint, manifest, and prediction digests.
