from __future__ import annotations

import copy
from dataclasses import dataclass

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchaudio
from peft import LoraConfig, TaskType, get_peft_model
from sklearn.metrics import f1_score
from torch.utils.data import DataLoader
from transformers import AutoModel, get_cosine_schedule_with_warmup


class LogMelFrontend(nn.Module):
    def __init__(self, sample_rate: int = 16000, mel_bins: int = 80) -> None:
        super().__init__()
        self.transform = torchaudio.transforms.MelSpectrogram(
            sample_rate=sample_rate,
            n_fft=400,
            win_length=400,
            hop_length=160,
            n_mels=mel_bins,
            f_min=20,
            f_max=7600,
            power=2.0,
        )

    def forward(self, waveform: torch.Tensor) -> torch.Tensor:
        values = self.transform(waveform).clamp_min(1e-8).log()
        values = (values - values.mean(dim=-1, keepdim=True)) / values.std(dim=-1, keepdim=True).clamp_min(1e-5)
        return values.transpose(1, 2)


class LogMelCNN(nn.Module):
    def __init__(self, class_count: int = 3) -> None:
        super().__init__()
        self.frontend = LogMelFrontend()
        self.network = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(), nn.AdaptiveAvgPool2d((1, 1)),
        )
        self.classifier = nn.Linear(128, class_count)

    def forward(self, waveform: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        del attention_mask
        representation = self.network(self.frontend(waveform).unsqueeze(1)).flatten(1)
        return self.classifier(representation)


class CRNN(nn.Module):
    def __init__(self, class_count: int = 3) -> None:
        super().__init__()
        self.frontend = LogMelFrontend()
        self.convolution = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d((1, 2)),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d((1, 2)),
            nn.Conv2d(64, 96, 3, padding=1), nn.ReLU(), nn.MaxPool2d((1, 2)),
        )
        self.recurrent = nn.LSTM(96 * 10, 256, num_layers=2, bidirectional=True, batch_first=True, dropout=0.2)
        self.classifier = nn.Linear(512, class_count)

    def forward(self, waveform: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        del attention_mask
        values = self.convolution(self.frontend(waveform).unsqueeze(1))
        values = values.permute(0, 2, 1, 3).flatten(2)
        values, _ = self.recurrent(values)
        return self.classifier(values.mean(dim=1))


class SEBlock(nn.Module):
    def __init__(self, channels: int, dilation: int) -> None:
        super().__init__()
        self.layers = nn.Sequential(
            nn.Conv1d(channels, channels, 1), nn.ReLU(),
            nn.Conv1d(channels, channels, 3, padding=dilation, dilation=dilation), nn.ReLU(),
            nn.Conv1d(channels, channels, 1), nn.BatchNorm1d(channels),
        )
        self.excitation = nn.Sequential(nn.Linear(channels, channels // 8), nn.ReLU(), nn.Linear(channels // 8, channels), nn.Sigmoid())

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        residual = values
        values = self.layers(values)
        scale = self.excitation(values.mean(dim=-1)).unsqueeze(-1)
        return F.relu(residual + values * scale)


class ECAPATDNN(nn.Module):
    def __init__(self, class_count: int = 3, channels: int = 512) -> None:
        super().__init__()
        self.frontend = LogMelFrontend()
        self.input = nn.Conv1d(80, channels, 5, padding=2)
        self.blocks = nn.Sequential(SEBlock(channels, 2), SEBlock(channels, 3), SEBlock(channels, 4))
        self.attention = nn.Sequential(nn.Conv1d(channels, 128, 1), nn.Tanh(), nn.Conv1d(128, 1, 1))
        self.classifier = nn.Linear(2 * channels, class_count)

    def forward(self, waveform: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        del attention_mask
        values = self.blocks(F.relu(self.input(self.frontend(waveform).transpose(1, 2))))
        weight = torch.softmax(self.attention(values), dim=-1)
        mean = (values * weight).sum(dim=-1)
        deviation = ((values - mean.unsqueeze(-1)).square() * weight).sum(dim=-1).clamp_min(1e-6).sqrt()
        return self.classifier(torch.cat([mean, deviation], dim=-1))


class ConformerClassifier(nn.Module):
    def __init__(self, class_count: int = 3) -> None:
        super().__init__()
        self.frontend = LogMelFrontend()
        self.project = nn.Linear(80, 256)
        self.encoder = torchaudio.models.Conformer(
            input_dim=256,
            num_heads=4,
            ffn_dim=1024,
            num_layers=12,
            depthwise_conv_kernel_size=31,
            dropout=0.1,
        )
        self.classifier = nn.Linear(512, class_count)

    def forward(self, waveform: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        values = self.project(self.frontend(waveform))
        lengths = attention_mask.sum(dim=1).float() / attention_mask.shape[1] * values.shape[1]
        values, lengths = self.encoder(values, lengths.long())
        mask = torch.arange(values.shape[1], device=values.device)[None, :] < lengths[:, None]
        weight = mask.to(values.dtype) / mask.sum(dim=1, keepdim=True).clamp_min(1)
        mean = (values * weight.unsqueeze(-1)).sum(dim=1)
        deviation = ((values - mean[:, None]).square() * weight.unsqueeze(-1)).sum(dim=1).clamp_min(1e-6).sqrt()
        return self.classifier(torch.cat([mean, deviation], dim=-1))


class SSLClassifier(nn.Module):
    def __init__(self, checkpoint: str, class_count: int = 3, rank: int = 8, attentive: bool = True) -> None:
        super().__init__()
        base = AutoModel.from_pretrained(checkpoint, trust_remote_code=checkpoint == "espnet/xeus")
        for parameter in base.parameters():
            parameter.requires_grad = False
        self.encoder = get_peft_model(
            base,
            LoraConfig(
                task_type=TaskType.FEATURE_EXTRACTION,
                r=rank,
                lora_alpha=2 * rank,
                lora_dropout=0.05,
                target_modules=["q_proj", "k_proj", "v_proj", "out_proj"],
                bias="none",
            ),
        )
        hidden = int(base.config.hidden_size)
        self.attentive = attentive
        self.attention = nn.Sequential(nn.Linear(hidden, 256), nn.Tanh(), nn.Linear(256, 1))
        self.classifier = nn.Linear(2 * hidden if attentive else hidden, class_count)

    def forward(self, waveform: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        values = self.encoder(input_values=waveform, attention_mask=attention_mask).last_hidden_state
        if not self.attentive:
            return self.classifier(values.mean(dim=1))
        weight = torch.softmax(self.attention(values).squeeze(-1), dim=1)
        mean = (values * weight.unsqueeze(-1)).sum(dim=1)
        deviation = ((values - mean[:, None]).square() * weight.unsqueeze(-1)).sum(dim=1).clamp_min(1e-6).sqrt()
        return self.classifier(torch.cat([mean, deviation], dim=-1))


def build_audio_baseline(name: str, config: dict, class_count: int = 3) -> nn.Module:
    if name == "logmel_cnn":
        return LogMelCNN(class_count)
    if name == "crnn":
        return CRNN(class_count)
    if name == "ecapa_tdnn":
        return ECAPATDNN(class_count, int(config["channels"]))
    if name == "conformer":
        return ConformerClassifier(class_count)
    checkpoint = str(config["checkpoint"])
    attentive = str(config.get("pooling", "attentive_statistics")) != "mean"
    return SSLClassifier(checkpoint, class_count, int(config.get("lora_rank", 8)), attentive)


@dataclass
class BaselineFit:
    state_dict: dict[str, torch.Tensor]
    best_epoch: int
    best_score: float


@torch.no_grad()
def predict_audio_baseline(model: nn.Module, loader: DataLoader, device: torch.device) -> tuple[np.ndarray, np.ndarray, list[str]]:
    model.eval()
    logits, labels, identifiers = [], [], []
    for batch in loader:
        output = model(batch["input_values"].to(device), batch["attention_mask"].to(device))
        logits.append(output.cpu().numpy())
        labels.append(batch["label"].numpy())
        identifiers.extend(batch["record_id"])
    return np.concatenate(logits), np.concatenate(labels), identifiers


def fit_audio_baseline(
    model: nn.Module,
    train_loader: DataLoader,
    validation_loader: DataLoader,
    class_weights: torch.Tensor,
    device: torch.device,
    epochs: int = 40,
    patience: int = 7,
) -> BaselineFit:
    model.to(device)
    optimizer = torch.optim.AdamW((parameter for parameter in model.parameters() if parameter.requires_grad), lr=2e-4, weight_decay=0.01)
    scheduler = get_cosine_schedule_with_warmup(optimizer, max(1, len(train_loader)), max(1, epochs * len(train_loader)))
    best_score, best_epoch, best_state, stale = -1.0, 0, None, 0
    for epoch in range(1, epochs + 1):
        model.train()
        for batch in train_loader:
            optimizer.zero_grad(set_to_none=True)
            logits = model(batch["input_values"].to(device), batch["attention_mask"].to(device))
            loss = F.cross_entropy(logits, batch["label"].to(device), weight=class_weights.to(device))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
        logits, labels, _ = predict_audio_baseline(model, validation_loader, device)
        score = float(f1_score(labels, logits.argmax(axis=1), average="macro"))
        if score > best_score + 1e-5:
            best_score, best_epoch = score, epoch
            best_state = copy.deepcopy({key: value.detach().cpu() for key, value in model.state_dict().items()})
            stale = 0
        else:
            stale += 1
        if stale >= patience:
            break
    if best_state is None:
        raise RuntimeError("Baseline training did not produce a checkpoint")
    model.load_state_dict(best_state)
    return BaselineFit(best_state, best_epoch, best_score)


def fit_temperature(logits: np.ndarray, labels: np.ndarray, device: torch.device) -> float:
    values = torch.tensor(logits, dtype=torch.float32, device=device)
    targets = torch.tensor(labels, dtype=torch.long, device=device)
    log_temperature = nn.Parameter(torch.zeros((), device=device))
    optimizer = torch.optim.LBFGS([log_temperature], lr=0.1, max_iter=100)

    def closure() -> torch.Tensor:
        optimizer.zero_grad(set_to_none=True)
        loss = F.cross_entropy(values / log_temperature.exp().clamp_min(0.05), targets)
        loss.backward()
        return loss

    optimizer.step(closure)
    return float(log_temperature.exp().detach().clamp_min(0.05).cpu())
