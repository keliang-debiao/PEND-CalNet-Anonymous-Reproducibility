from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch

from .calibration import apply_calibrator, fit_margin_quality_calibrator, fit_source_moments
from .metrics import classification_metrics
from .training import (
    build_model,
    estimate_normalization,
    fit_stage_one,
    make_dataset,
    make_loader,
    predict_logits,
    predict_sliding_windows,
)


def score_source_candidate(
    config: dict[str, Any],
    variant: dict[str, Any],
    partitions: pd.DataFrame,
    seed: int,
    batch_size: int,
    workers: int,
    device: torch.device,
) -> float:
    stage_one = partitions[partitions["partition"] == "stage1_train"].copy()
    inner = partitions[partitions["partition"] == "inner_validation"].copy()
    normalization = estimate_normalization(
        stage_one,
        config["project"]["class_to_index"],
        int(config["data"]["sample_rate"]),
        float(config["data"]["window_seconds"]),
        seed,
    )
    train_dataset = make_dataset(stage_one, config, normalization, True, seed)
    inner_dataset = make_dataset(inner, config, normalization, False, seed)
    model = build_model(config, len(train_dataset.speaker_map), len(train_dataset.prompt_map), variant).to(device)
    fitted = fit_stage_one(
        model,
        make_loader(train_dataset, batch_size, True, workers, seed),
        make_loader(inner_dataset, batch_size, False, workers, seed),
        stage_one,
        config,
        variant,
        normalization,
        device,
    )
    return fitted.best_macro_f1


def run_source_partition(
    config: dict[str, Any],
    variant: dict[str, Any],
    partitions: pd.DataFrame,
    output_directory: Path,
    seed: int,
    batch_size: int,
    workers: int,
    device: torch.device,
    evaluation_partition: str,
) -> dict[str, Any]:
    output_directory.mkdir(parents=True, exist_ok=True)
    stage_one = partitions[partitions["partition"] == "stage1_train"].copy()
    inner = partitions[partitions["partition"] == "inner_validation"].copy()
    calibration = partitions[partitions["partition"] == "source_calibration"].copy()
    evaluation = partitions[partitions["partition"] == evaluation_partition].copy()
    if any(frame.empty for frame in [stage_one, inner, calibration, evaluation]):
        raise ValueError("Every source partition and the evaluation partition must contain records")
    normalization = estimate_normalization(
        stage_one,
        config["project"]["class_to_index"],
        int(config["data"]["sample_rate"]),
        float(config["data"]["window_seconds"]),
        seed,
    )
    datasets = {
        "stage1_train": make_dataset(stage_one, config, normalization, True, seed),
        "inner_validation": make_dataset(inner, config, normalization, False, seed),
        "source_calibration": make_dataset(calibration, config, normalization, False, seed),
        "evaluation": make_dataset(evaluation, config, normalization, False, seed),
    }
    loaders = {
        key: make_loader(dataset, batch_size, key == "stage1_train", workers, seed)
        for key, dataset in datasets.items()
    }
    model = build_model(
        config,
        speaker_count=datasets["stage1_train"].speaker_map.__len__(),
        prompt_count=datasets["stage1_train"].prompt_map.__len__(),
        variant=variant,
    ).to(device)
    fitted = fit_stage_one(
        model,
        loaders["stage1_train"],
        loaders["inner_validation"],
        stage_one,
        config,
        variant,
        normalization,
        device,
    )
    outputs = {
        "stage1_train": predict_logits(model, loaders["stage1_train"], device),
        "source_calibration": predict_sliding_windows(model, calibration, normalization, config, device),
        "evaluation": predict_sliding_windows(model, evaluation, normalization, config, device),
    }
    moments = fit_source_moments(outputs["stage1_train"]["representation"], outputs["stage1_train"]["quality"])
    calibration_quality = moments.transform(
        outputs["source_calibration"]["representation"],
        outputs["source_calibration"]["quality"],
    )
    calibrator = fit_margin_quality_calibrator(
        outputs["source_calibration"]["logits"],
        calibration_quality,
        outputs["source_calibration"]["labels"],
        hidden_size=int(config["calibration"]["hidden_size"]),
        temperature_min=float(config["calibration"]["temperature_min"]),
        reliability_weight=float(config["calibration"]["reliability_weight"]),
        soft_bins=int(config["calibration"]["soft_bins"]),
        bandwidth=float(config["calibration"]["bandwidth"]),
        epsilon=float(config["calibration"]["charbonnier_epsilon"]),
        learning_rate=float(config["calibration"]["lr"]),
        weight_decay=float(config["calibration"]["weight_decay"]),
        epochs=int(config["calibration"]["epochs"]),
        patience=int(config["calibration"]["patience"]),
        seed=seed,
        device=device,
    )
    evaluation_quality = moments.transform(outputs["evaluation"]["representation"], outputs["evaluation"]["quality"])
    if "quality_adaptive_calibration" in set(variant.get("disable", [])):
        probabilities = torch.softmax(torch.from_numpy(outputs["evaluation"]["logits"]), dim=-1).numpy()
        temperatures = np.ones(len(probabilities), dtype=np.float32)
    else:
        probabilities, temperatures = apply_calibrator(
            calibrator,
            outputs["evaluation"]["logits"],
            evaluation_quality,
            device,
        )
    metrics = classification_metrics(
        probabilities,
        outputs["evaluation"]["labels"],
        bins=int(config["calibration"]["hard_ece_bins"]),
    ).as_dict()
    prediction_frame = pd.DataFrame(
        {
            "record_id": outputs["evaluation"]["record_id"],
            "label": outputs["evaluation"]["labels"],
            "predicted": probabilities.argmax(axis=1),
            "temperature": temperatures,
            "mean_fusion_gate": outputs["evaluation"]["fusion_gate"],
            "prob_u_tsang": probabilities[:, 0],
            "prob_amdo": probabilities[:, 1],
            "prob_kham": probabilities[:, 2],
        }
    )
    prediction_frame.to_csv(output_directory / "predictions.csv", index=False)
    pd.DataFrame(fitted.history).to_csv(output_directory / "training_history.csv", index=False)
    checkpoint = {
        "model_state": fitted.state_dict,
        "calibrator_state": calibrator.state_dict(),
        "normalization": normalization.state_dict(),
        "source_moments": moments.state_dict(),
        "speaker_count": len(datasets["stage1_train"].speaker_map),
        "prompt_count": len(datasets["stage1_train"].prompt_map),
        "variant": variant,
        "resolved_config": config,
        "best_epoch": fitted.best_epoch,
        "seed": seed,
    }
    torch.save(checkpoint, output_directory / "checkpoint.pt")
    record = {
        "metrics": metrics,
        "best_epoch": fitted.best_epoch,
        "inner_macro_f1": fitted.best_macro_f1,
        "counts": {key: len(value) for key, value in datasets.items()},
    }
    (output_directory / "metrics.json").write_text(json.dumps(record, indent=2, sort_keys=True), encoding="utf-8")
    return record
