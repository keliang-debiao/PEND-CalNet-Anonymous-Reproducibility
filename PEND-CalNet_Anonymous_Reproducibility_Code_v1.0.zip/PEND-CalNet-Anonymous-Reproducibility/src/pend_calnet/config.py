from __future__ import annotations

import hashlib
import json
import os
import random
from pathlib import Path
from typing import Any

import numpy as np
import yaml


def load_config(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    with path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    required = {"project", "data", "encoder", "model", "loss", "optimization", "calibration"}
    missing = sorted(required.difference(config))
    if missing:
        raise ValueError(f"Missing configuration sections: {missing}")
    return config


def config_digest(config: dict[str, Any]) -> str:
    payload = json.dumps(config, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def seed_everything(seed: int, deterministic: bool = True) -> None:
    import torch

    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.use_deterministic_algorithms(True, warn_only=True)
        torch.backends.cudnn.benchmark = False


def deep_update(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_update(result[key], value)
        else:
            result[key] = value
    return result


def apply_selected_parameters(config: dict[str, Any], parameters: dict[str, Any]) -> dict[str, Any]:
    result = deep_update(config, {})
    if "lora_rank" in parameters:
        result["encoder"]["lora"]["rank"] = int(parameters["lora_rank"])
    for key in ["encoder_lora_lr", "new_layer_lr"]:
        if key in parameters:
            result["optimization"][key] = float(parameters[key])
    if "feature_dropout" in parameters:
        result["model"]["feature_dropout"] = float(parameters["feature_dropout"])
    for key in ["phonological_evidence", "nuisance_disentanglement", "supervised_contrastive", "augmentation_consistency", "contrastive_temperature"]:
        if key in parameters:
            result["loss"][key] = float(parameters[key])
    return result


def atomic_json_dump(payload: Any, destination: str | Path) -> None:
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".partial")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(destination)

