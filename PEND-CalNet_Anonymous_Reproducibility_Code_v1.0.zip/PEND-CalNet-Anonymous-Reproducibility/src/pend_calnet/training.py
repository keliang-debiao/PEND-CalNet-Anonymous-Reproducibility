from __future__ import annotations

import copy
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import f1_score
from torch.utils.data import DataLoader
from tqdm.auto import tqdm
from transformers import get_cosine_schedule_with_warmup

from .audio import acoustic_tracks, load_mono, pitch_flatten_world, quality_descriptors, window_waveform
from .data import TibetanDialectDataset, collate_records
from .losses import LossBundle, total_training_loss
from .model import PENDCalNet, XLSRFrameEncoder


@dataclass
class NormalizationState:
    track_mean: torch.Tensor
    track_std: torch.Tensor
    quality_mean: torch.Tensor
    quality_std: torch.Tensor

    def state_dict(self) -> dict[str, list[float]]:
        return {
            "track_mean": self.track_mean.tolist(),
            "track_std": self.track_std.tolist(),
            "quality_mean": self.quality_mean.tolist(),
            "quality_std": self.quality_std.tolist(),
        }

    @classmethod
    def from_state_dict(cls, state: dict[str, list[float]]) -> "NormalizationState":
        return cls(
            track_mean=torch.tensor(state["track_mean"], dtype=torch.float32),
            track_std=torch.tensor(state["track_std"], dtype=torch.float32),
            quality_mean=torch.tensor(state["quality_mean"], dtype=torch.float32),
            quality_std=torch.tensor(state["quality_std"], dtype=torch.float32),
        )


@dataclass
class FitResult:
    best_epoch: int
    best_macro_f1: float
    history: list[dict[str, float]]
    state_dict: dict[str, torch.Tensor]


def estimate_normalization(
    frame: pd.DataFrame,
    class_to_index: dict[str, int],
    sample_rate: int,
    window_seconds: float,
    seed: int,
) -> NormalizationState:
    dataset = TibetanDialectDataset(
        frame,
        class_to_index,
        sample_rate=sample_rate,
        window_seconds=window_seconds,
        training=False,
        seed=seed,
    )
    track_sum = torch.zeros(7, dtype=torch.float64)
    track_squared = torch.zeros(7, dtype=torch.float64)
    track_count = 0
    quality_values = []
    for index in tqdm(range(len(dataset)), desc="source normalization", leave=False):
        item = dataset[index]
        tracks = item["acoustic_cues"].double()
        track_sum += tracks.sum(dim=0)
        track_squared += tracks.square().sum(dim=0)
        track_count += tracks.shape[0]
        quality_values.append(item["quality"].double())
    track_mean = track_sum / max(1, track_count)
    track_var = track_squared / max(1, track_count) - track_mean.square()
    quality = torch.stack(quality_values)
    return NormalizationState(
        track_mean=track_mean.float(),
        track_std=track_var.clamp_min(1e-12).sqrt().float(),
        quality_mean=quality.mean(dim=0).float(),
        quality_std=quality.std(dim=0, unbiased=True).clamp_min(1e-6).float(),
    )


def make_dataset(
    frame: pd.DataFrame,
    config: dict[str, Any],
    normalization: NormalizationState,
    training: bool,
    seed: int,
) -> TibetanDialectDataset:
    return TibetanDialectDataset(
        frame,
        config["project"]["class_to_index"],
        sample_rate=int(config["data"]["sample_rate"]),
        window_seconds=float(config["data"]["window_seconds"]),
        training=training,
        seed=seed,
        track_mean=normalization.track_mean,
        track_std=normalization.track_std,
        quality_mean=normalization.quality_mean,
        quality_std=normalization.quality_std,
    )


def make_loader(
    dataset: TibetanDialectDataset,
    batch_size: int,
    shuffle: bool,
    workers: int,
    seed: int,
) -> DataLoader:
    generator = torch.Generator().manual_seed(seed)
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=workers,
        collate_fn=collate_records,
        pin_memory=torch.cuda.is_available(),
        generator=generator,
        persistent_workers=workers > 0,
    )


def build_model(config: dict[str, Any], speaker_count: int, prompt_count: int, variant: dict[str, Any]) -> PENDCalNet:
    encoder_cfg = config["encoder"]
    model_cfg = config["model"]
    lora_cfg = encoder_cfg["lora"]
    encoder = XLSRFrameEncoder(
        encoder_cfg["checkpoint"],
        rank=int(lora_cfg["rank"]),
        alpha=int(lora_cfg["alpha"]),
        dropout=float(lora_cfg["dropout"]),
        targets=list(lora_cfg["targets"]),
        trainable_block_start=int(encoder_cfg["trainable_block_start"]),
        transformer_blocks=int(encoder_cfg["transformer_blocks"]),
    )
    return PENDCalNet(
        encoder=encoder,
        hidden_size=int(encoder.hidden_size),
        class_count=len(config["project"]["classes"]),
        speaker_count=speaker_count,
        prompt_count=prompt_count,
        cue_size=int(model_cfg["acoustic_tracks"]),
        dialect_size=int(model_cfg["dialect_size"]),
        evidence_size=int(model_cfg["evidence_projection_size"]),
        nuisance_size=int(model_cfg["nuisance_size"]),
        adversary_hidden_size=int(model_cfg["adversary_hidden_size"]),
        dropout=float(model_cfg["feature_dropout"]),
        use_quality_pooling="quality_attentive_pooling" not in set(variant.get("disable", [])),
    )


def class_balancing_weights(frame: pd.DataFrame, class_to_index: dict[str, int]) -> torch.Tensor:
    counts = frame["label"].value_counts()
    total = float(len(frame))
    weights = [total / (len(class_to_index) * float(counts.get(label, 1))) for label in class_to_index]
    return torch.tensor(weights, dtype=torch.float32)


def _device_batch(batch: dict[str, Any], device: torch.device) -> dict[str, Any]:
    return {key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value for key, value in batch.items()}


def _augmented_view(batch: dict[str, Any]) -> dict[str, Any]:
    output = {key: value for key, value in batch.items()}
    waveform = batch["input_values"]
    noise = torch.randn_like(waveform) * 0.002
    output["input_values"] = (waveform + noise).clamp(-0.999, 0.999)
    retain = (torch.rand_like(batch["acoustic_cues"][..., :1]) > 0.05).to(batch["acoustic_cues"].dtype)
    output["acoustic_cues"] = batch["acoustic_cues"] * retain
    return output


def _flattened_view(
    batch: dict[str, Any],
    config: dict[str, Any],
    normalization: NormalizationState,
) -> dict[str, Any]:
    sample_rate = int(config["data"]["sample_rate"])
    waveforms = []
    tracks = []
    qualities = []
    for waveform in batch["input_values"]:
        flattened = pitch_flatten_world(waveform, sample_rate=sample_rate, fraction=1.0).to(waveform.device)
        waveforms.append(flattened)
        cues = acoustic_tracks(flattened, sample_rate)
        cues = (cues - normalization.track_mean.to(cues.device)) / normalization.track_std.to(cues.device)
        descriptor = quality_descriptors(flattened, sample_rate)
        descriptor = (descriptor - normalization.quality_mean.to(descriptor.device)) / normalization.quality_std.to(descriptor.device)
        tracks.append(cues.to(waveform.device))
        qualities.append(descriptor.to(waveform.device))
    output = {key: value for key, value in batch.items()}
    output["input_values"] = torch.stack(waveforms)
    output["acoustic_cues"] = torch.stack(tracks)
    output["quality"] = torch.stack(qualities)
    return output


def _forward(model: PENDCalNet, batch: dict[str, Any], coefficient: float) -> Any:
    return model(
        batch["input_values"],
        batch["attention_mask"],
        batch["acoustic_cues"],
        batch["quality"],
        labels=batch["label"],
        gradient_reversal=coefficient,
    )


def _loss_weights(config: dict[str, Any], variant: dict[str, Any]) -> dict[str, float]:
    weights = {key: float(value) for key, value in config["loss"].items()}
    disabled = set(variant.get("disable", []))
    mapping = {
        "phonological_counterfactual": "phonological_evidence",
        "nuisance_disentanglement": "nuisance_disentanglement",
        "supervised_contrastive": "supervised_contrastive",
        "augmentation_consistency": "augmentation_consistency",
    }
    for component, key in mapping.items():
        if component in disabled:
            weights[key] = 0.0
    return weights


@torch.no_grad()
def predict_logits(model: PENDCalNet, loader: DataLoader, device: torch.device) -> dict[str, np.ndarray]:
    model.eval()
    storage: dict[str, list[np.ndarray]] = {
        "logits": [],
        "labels": [],
        "quality": [],
        "representation": [],
        "fusion_gate": [],
        "record_id": [],
    }
    for batch in tqdm(loader, desc="inference", leave=False):
        batch = _device_batch(batch, device)
        output = _forward(model, batch, coefficient=0.0)
        storage["logits"].append(output.logits.cpu().numpy())
        storage["labels"].append(batch["label"].cpu().numpy())
        storage["quality"].append(batch["quality"].cpu().numpy())
        storage["representation"].append(output.dialect_representation.cpu().numpy())
        storage["fusion_gate"].append(output.fusion_gate.mean(dim=(1, 2)).cpu().numpy())
        storage["record_id"].append(np.asarray(batch["record_id"], dtype=object))
    return {key: np.concatenate(value, axis=0) for key, value in storage.items()}


@torch.no_grad()
def predict_sliding_windows(
    model: PENDCalNet,
    frame: pd.DataFrame,
    normalization: NormalizationState,
    config: dict[str, Any],
    device: torch.device,
    waveform_transform=None,
    cue_transform=None,
) -> dict[str, np.ndarray]:
    model.eval()
    sample_rate = int(config["data"]["sample_rate"])
    window_seconds = float(config["data"]["window_seconds"])
    hop_seconds = float(config["data"]["inference_hop_seconds"])
    class_to_index = config["project"]["class_to_index"]
    storage: dict[str, list[Any]] = {
        "logits": [],
        "labels": [],
        "quality": [],
        "representation": [],
        "fusion_gate": [],
        "record_id": [],
    }
    for row in tqdm(frame.itertuples(index=False), total=len(frame), desc="sliding inference", leave=False):
        waveform = load_mono(row.audio_path, sample_rate)
        if waveform_transform is not None:
            waveform = waveform_transform(waveform, row)
        windows = window_waveform(waveform, sample_rate, window_seconds, hop_seconds)
        input_values = torch.stack([item[0] for item in windows]).to(device)
        attention_mask = torch.stack([item[1] for item in windows]).to(device)
        cues = torch.stack([acoustic_tracks(item[0], sample_rate) for item in windows])
        if cue_transform is not None:
            cues = cue_transform(cues, row)
        cues = (cues - normalization.track_mean) / normalization.track_std
        quality = torch.stack([quality_descriptors(item[0], sample_rate) for item in windows])
        quality = (quality - normalization.quality_mean) / normalization.quality_std
        output = model(
            input_values,
            attention_mask,
            cues.to(device),
            quality.to(device),
            gradient_reversal=0.0,
        )
        storage["logits"].append(output.logits.mean(dim=0).cpu().numpy())
        storage["representation"].append(output.dialect_representation.mean(dim=0).cpu().numpy())
        storage["quality"].append(quality.mean(dim=0).numpy())
        storage["fusion_gate"].append(float(output.fusion_gate.mean().cpu()))
        storage["labels"].append(int(class_to_index[str(row.label)]))
        storage["record_id"].append(str(row.record_id))
    return {
        key: np.asarray(value, dtype=object if key == "record_id" else None)
        for key, value in storage.items()
    }


def fit_stage_one(
    model: PENDCalNet,
    train_loader: DataLoader,
    validation_loader: DataLoader,
    train_frame: pd.DataFrame,
    config: dict[str, Any],
    variant: dict[str, Any],
    normalization: NormalizationState,
    device: torch.device,
) -> FitResult:
    optimization = config["optimization"]
    new_parameters = []
    encoder_parameters = []
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        (encoder_parameters if name.startswith("encoder.") else new_parameters).append(parameter)
    optimizer = torch.optim.AdamW(
        [
            {"params": encoder_parameters, "lr": float(optimization["encoder_lora_lr"])},
            {"params": new_parameters, "lr": float(optimization["new_layer_lr"])},
        ],
        weight_decay=float(optimization["weight_decay"]),
    )
    epochs = int(optimization["epochs"])
    total_steps = max(1, epochs * len(train_loader))
    warmup = int(round(total_steps * float(optimization["warmup_fraction"])))
    scheduler = get_cosine_schedule_with_warmup(optimizer, warmup, total_steps)
    amp_enabled = bool(optimization["amp"] and device.type == "cuda")
    scaler = torch.cuda.amp.GradScaler(enabled=amp_enabled)
    class_weights = class_balancing_weights(train_frame, config["project"]["class_to_index"]).to(device)
    loss_weights = _loss_weights(config, variant)
    best_score = -math.inf
    best_state = None
    best_epoch = 0
    stale = 0
    history: list[dict[str, float]] = []
    model.to(device)
    for epoch in range(1, epochs + 1):
        model.train()
        running = {key: 0.0 for key in LossBundle.__annotations__}
        coefficient = min(
            float(config["model"]["gradient_reversal_max"]),
            epoch / max(1, int(config["model"]["gradient_reversal_ramp_epochs"])),
        )
        for batch in tqdm(train_loader, desc=f"epoch {epoch}", leave=False):
            batch = _device_batch(batch, device)
            view_b = _augmented_view(batch)
            flattened = (
                _flattened_view(batch, config, normalization)
                if loss_weights["phonological_evidence"] > 0
                else batch
            )
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, enabled=amp_enabled):
                output_a = _forward(model, batch, coefficient)
                output_b = _forward(model, view_b, coefficient)
                output_flattened = _forward(model, flattened, coefficient)
                prompt_mask = torch.ones_like(batch["prompt"], dtype=torch.bool)
                bundle = total_training_loss(
                    output_a,
                    output_b,
                    output_flattened,
                    batch["label"],
                    batch["speaker"],
                    batch["prompt"],
                    prompt_mask,
                    class_weights,
                    loss_weights,
                    response_margin=float(config["model"]["counterfactual_response_margin"]),
                )
            scaler.scale(bundle.total).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(optimization["gradient_norm"]))
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()
            for key in running:
                running[key] += float(getattr(bundle, key).detach())
        validation = predict_logits(model, validation_loader, device)
        probabilities = torch.softmax(torch.from_numpy(validation["logits"]), dim=-1).numpy()
        score = float(f1_score(validation["labels"], probabilities.argmax(axis=1), average="macro"))
        record = {"epoch": float(epoch), "validation_macro_f1": score, "gradient_reversal": coefficient}
        record.update({key: value / max(1, len(train_loader)) for key, value in running.items()})
        history.append(record)
        if score > best_score + 1e-5:
            best_score = score
            best_epoch = epoch
            best_state = copy.deepcopy({key: value.detach().cpu() for key, value in model.state_dict().items()})
            stale = 0
        else:
            stale += 1
        if stale >= int(optimization["patience"]):
            break
    if best_state is None:
        raise RuntimeError("Training did not produce a valid checkpoint")
    model.load_state_dict(best_state)
    return FitResult(best_epoch, best_score, history, best_state)


def save_checkpoint(path: str | Path, model: PENDCalNet, normalization: NormalizationState, metadata: dict[str, Any]) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model_state": model.state_dict(),
            "normalization": normalization.state_dict(),
            "metadata": metadata,
        },
        path,
    )
