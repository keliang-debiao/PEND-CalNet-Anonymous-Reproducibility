from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, log_loss, roc_auc_score


@dataclass(frozen=True)
class MetricBundle:
    macro_f1: float
    uar: float
    accuracy: float
    macro_auroc: float
    ece: float
    brier: float
    nll: float
    calibration_slope: float
    calibration_intercept: float

    def as_dict(self) -> dict[str, float]:
        return self.__dict__.copy()


def equal_frequency_ece(probabilities: np.ndarray, labels: np.ndarray, bins: int = 15) -> float:
    confidence = probabilities.max(axis=1)
    predictions = probabilities.argmax(axis=1)
    correctness = (predictions == labels).astype(np.float64)
    order = np.argsort(confidence, kind="mergesort")
    partitions = np.array_split(order, min(bins, len(order)))
    return float(
        sum(
            len(index) / len(labels) * abs(correctness[index].mean() - confidence[index].mean())
            for index in partitions
            if len(index)
        )
    )


def multiclass_brier(probabilities: np.ndarray, labels: np.ndarray) -> float:
    targets = np.eye(probabilities.shape[1], dtype=np.float64)[labels]
    return float(np.mean(np.sum((probabilities - targets) ** 2, axis=1)))


def confidence_calibration_coefficients(probabilities: np.ndarray, labels: np.ndarray) -> tuple[float, float]:
    confidence = np.clip(probabilities.max(axis=1), 1e-6, 1.0 - 1e-6)
    correctness = (probabilities.argmax(axis=1) == labels).astype(np.int64)
    if np.unique(correctness).size < 2:
        return float("nan"), float("nan")
    logit_confidence = np.log(confidence / (1.0 - confidence))[:, None]
    fitted = LogisticRegression(C=1e6, solver="lbfgs", max_iter=2000).fit(logit_confidence, correctness)
    return float(fitted.coef_[0, 0]), float(fitted.intercept_[0])


def classification_metrics(probabilities: np.ndarray, labels: np.ndarray, bins: int = 15) -> MetricBundle:
    probabilities = np.asarray(probabilities, dtype=np.float64)
    labels = np.asarray(labels, dtype=np.int64)
    if probabilities.ndim != 2 or probabilities.shape[0] != labels.shape[0]:
        raise ValueError("Probability and label dimensions are inconsistent")
    predictions = probabilities.argmax(axis=1)
    class_count = probabilities.shape[1]
    slope, intercept = confidence_calibration_coefficients(probabilities, labels)
    try:
        auroc = roc_auc_score(
            labels,
            probabilities,
            labels=np.arange(class_count),
            multi_class="ovr",
            average="macro",
        )
    except ValueError:
        auroc = float("nan")
    return MetricBundle(
        macro_f1=float(f1_score(labels, predictions, average="macro", zero_division=0)),
        uar=float(balanced_accuracy_score(labels, predictions)),
        accuracy=float(accuracy_score(labels, predictions)),
        macro_auroc=float(auroc),
        ece=equal_frequency_ece(probabilities, labels, bins=bins),
        brier=multiclass_brier(probabilities, labels),
        nll=float(log_loss(labels, probabilities, labels=np.arange(class_count))),
        calibration_slope=slope,
        calibration_intercept=intercept,
    )


def mean_sd_t_ci(values: np.ndarray, confidence: float = 0.95) -> tuple[float, float, float, float]:
    from scipy.stats import t

    values = np.asarray(values, dtype=np.float64)
    mean = float(values.mean())
    sd = float(values.std(ddof=1)) if len(values) > 1 else 0.0
    if len(values) < 2:
        return mean, sd, mean, mean
    quantile = float(t.ppf(0.5 + confidence / 2.0, len(values) - 1))
    half_width = quantile * sd / np.sqrt(len(values))
    return mean, sd, mean - half_width, mean + half_width


def selective_risk(probabilities: np.ndarray, labels: np.ndarray, coverage: float) -> float:
    if not 0.0 < coverage <= 1.0:
        raise ValueError("Coverage must be within (0, 1]")
    confidence = probabilities.max(axis=1)
    retained = max(1, int(np.ceil(len(labels) * coverage)))
    chosen = np.argsort(-confidence, kind="mergesort")[:retained]
    return float(1.0 - (probabilities[chosen].argmax(axis=1) == labels[chosen]).mean())
