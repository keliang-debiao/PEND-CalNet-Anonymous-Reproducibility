from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parents[2]
    command = [sys.executable, str(root / "scripts" / "verify_package.py")]
    raise SystemExit(subprocess.call(command, cwd=root))


if __name__ == "__main__":
    main()
