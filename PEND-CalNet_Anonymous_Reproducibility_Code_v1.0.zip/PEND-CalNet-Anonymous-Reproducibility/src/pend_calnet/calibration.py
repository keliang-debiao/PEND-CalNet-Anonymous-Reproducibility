from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.covariance import LedoitWolf
from torch.utils.data import DataLoader

from .losses import soft_calibration_error
from .model import MarginQualityAdaptiveCalibrator


@dataclass
class SourceMoments:
    representation_mean: np.ndarray
    precision: np.ndarray
    quality_mean: np.ndarray
    quality_std: np.ndarray
    distance_mean: float
    distance_std: float

    def transform(self, representations: np.ndarray, quality: np.ndarray) -> np.ndarray:
        centered = representations - self.representation_mean
        squared = np.einsum("bi,ij,bj->b", centered, self.precision, centered)
        distance = np.sqrt(np.maximum(squared, 0.0) / representations.shape[1])
        standardized_quality = (quality - self.quality_mean) / np.maximum(self.quality_std, 1e-6)
        standardized_distance = (distance - self.distance_mean) / max(self.distance_std, 1e-6)
        return np.concatenate([standardized_quality, standardized_distance[:, None]], axis=1)

    def state_dict(self) -> dict[str, object]:
        return {
            "representation_mean": self.representation_mean.tolist(),
            "precision": self.precision.tolist(),
            "quality_mean": self.quality_mean.tolist(),
            "quality_std": self.quality_std.tolist(),
            "distance_mean": self.distance_mean,
            "distance_std": self.distance_std,
        }

    @classmethod
    def from_state_dict(cls, state: dict[str, object]) -> "SourceMoments":
        return cls(
            representation_mean=np.asarray(state["representation_mean"], dtype=np.float64),
            precision=np.asarray(state["precision"], dtype=np.float64),
            quality_mean=np.asarray(state["quality_mean"], dtype=np.float64),
            quality_std=np.asarray(state["quality_std"], dtype=np.float64),
            distance_mean=float(state["distance_mean"]),
            distance_std=float(state["distance_std"]),
        )


def fit_source_moments(representations: np.ndarray, quality: np.ndarray) -> SourceMoments:
    if representations.ndim != 2 or quality.ndim != 2:
        raise ValueError("Representations and quality descriptors must be two-dimensional")
    covariance = LedoitWolf().fit(representations)
    centered = representations - covariance.location_
    squared = np.einsum("bi,ij,bj->b", centered, covariance.precision_, centered)
    distance = np.sqrt(np.maximum(squared, 0.0) / representations.shape[1])
    return SourceMoments(
        representation_mean=covariance.location_.astype(np.float64),
        precision=covariance.precision_.astype(np.float64),
        quality_mean=quality.mean(axis=0).astype(np.float64),
        quality_std=quality.std(axis=0, ddof=1).astype(np.float64),
        distance_mean=float(distance.mean()),
        distance_std=float(distance.std(ddof=1)),
    )


@torch.no_grad()
def collect_frozen_outputs(model: torch.nn.Module, loader: DataLoader, device: torch.device) -> dict[str, np.ndarray]:
    model.eval()
    collected: dict[str, list[np.ndarray]] = {
        "logits": [],
        "representation": [],
        "quality": [],
        "labels": [],
        "record_id": [],
    }
    for batch in loader:
        tensor_batch = {
            key: value.to(device)
            for key, value in batch.items()
            if isinstance(value, torch.Tensor)
        }
        output = model(
            tensor_batch["input_values"],
            tensor_batch["attention_mask"],
            tensor_batch["acoustic_cues"],
            tensor_batch["quality"],
        )
        collected["logits"].append(output.logits.detach().cpu().numpy())
        collected["representation"].append(output.dialect_representation.detach().cpu().numpy())
        collected["quality"].append(tensor_batch["quality"].detach().cpu().numpy())
        collected["labels"].append(tensor_batch["label"].detach().cpu().numpy())
        collected["record_id"].append(np.asarray(batch["record_id"], dtype=object))
    return {key: np.concatenate(value, axis=0) for key, value in collected.items()}


def fit_margin_quality_calibrator(
    logits: np.ndarray,
    calibration_quality: np.ndarray,
    labels: np.ndarray,
    hidden_size: int,
    temperature_min: float,
    reliability_weight: float,
    soft_bins: int,
    bandwidth: float,
    epsilon: float,
    learning_rate: float,
    weight_decay: float,
    epochs: int,
    patience: int,
    seed: int,
    device: torch.device,
) -> MarginQualityAdaptiveCalibrator:
    torch.manual_seed(seed)
    module = MarginQualityAdaptiveCalibrator(
        quality_size=calibration_quality.shape[1],
        hidden_size=hidden_size,
        temperature_min=temperature_min,
    ).to(device)
    optimizer = torch.optim.AdamW(
        module.parameters(),
        lr=learning_rate,
        weight_decay=weight_decay,
    )
    logits_tensor = torch.as_tensor(logits, dtype=torch.float32, device=device)
    quality_tensor = torch.as_tensor(calibration_quality, dtype=torch.float32, device=device)
    labels_tensor = torch.as_tensor(labels, dtype=torch.long, device=device)
    best_loss = float("inf")
    best_state: dict[str, torch.Tensor] | None = None
    stale = 0
    for _ in range(epochs):
        module.train()
        optimizer.zero_grad(set_to_none=True)
        probabilities, temperature = module(logits_tensor, quality_tensor)
        calibrated_logits = logits_tensor / temperature.unsqueeze(-1)
        objective = F.cross_entropy(calibrated_logits, labels_tensor)
        objective = objective + reliability_weight * soft_calibration_error(
            probabilities,
            labels_tensor,
            bins=soft_bins,
            bandwidth=bandwidth,
            epsilon=epsilon,
        )
        objective.backward()
        optimizer.step()
        value = float(objective.detach())
        if value < best_loss - 1e-6:
            best_loss = value
            best_state = {key: tensor.detach().cpu().clone() for key, tensor in module.state_dict().items()}
            stale = 0
        else:
            stale += 1
        if stale >= patience:
            break
    if best_state is None:
        raise RuntimeError("Calibration optimization did not produce a valid state")
    module.load_state_dict(best_state)
    return module


@torch.no_grad()
def apply_calibrator(
    module: MarginQualityAdaptiveCalibrator,
    logits: np.ndarray,
    calibration_quality: np.ndarray,
    device: torch.device,
) -> tuple[np.ndarray, np.ndarray]:
    module.eval()
    probabilities, temperatures = module(
        torch.as_tensor(logits, dtype=torch.float32, device=device),
        torch.as_tensor(calibration_quality, dtype=torch.float32, device=device),
    )
    return probabilities.cpu().numpy(), temperatures.cpu().numpy()
