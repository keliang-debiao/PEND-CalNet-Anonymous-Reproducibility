from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F
from peft import LoraConfig, TaskType, get_peft_model
from transformers import AutoModel


class GradientReverseFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx: Any, values: torch.Tensor, coefficient: float) -> torch.Tensor:
        ctx.coefficient = coefficient
        return values.view_as(values)

    @staticmethod
    def backward(ctx: Any, gradient: torch.Tensor) -> tuple[torch.Tensor, None]:
        return -ctx.coefficient * gradient, None


def gradient_reverse(values: torch.Tensor, coefficient: float) -> torch.Tensor:
    return GradientReverseFunction.apply(values, coefficient)


class XLSRFrameEncoder(nn.Module):
    def __init__(
        self,
        checkpoint: str,
        rank: int = 8,
        alpha: int = 16,
        dropout: float = 0.05,
        targets: list[str] | None = None,
        trainable_block_start: int = 13,
        transformer_blocks: int = 24,
    ) -> None:
        super().__init__()
        base = AutoModel.from_pretrained(checkpoint)
        for parameter in base.parameters():
            parameter.requires_grad = False
        lora = LoraConfig(
            task_type=TaskType.FEATURE_EXTRACTION,
            r=rank,
            lora_alpha=alpha,
            lora_dropout=dropout,
            target_modules=targets or ["q_proj", "k_proj", "v_proj", "out_proj"],
            layers_to_transform=list(range(trainable_block_start - 1, transformer_blocks)),
            layers_pattern="layers",
            bias="none",
        )
        self.model = get_peft_model(base, lora)
        self.hidden_size = int(base.config.hidden_size)

    def forward(
        self,
        input_values: torch.Tensor,
        attention_mask: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        output = self.model(input_values=input_values, attention_mask=attention_mask)
        frames = output.last_hidden_state
        frame_mask = None
        base = self.model.get_base_model()
        if attention_mask is not None and hasattr(base, "_get_feature_vector_attention_mask"):
            frame_mask = base._get_feature_vector_attention_mask(frames.shape[1], attention_mask)
        return frames, frame_mask


class CounterfactualPhonologicalEvidenceFusion(nn.Module):
    def __init__(self, hidden_size: int, cue_size: int = 7, dropout: float = 0.10) -> None:
        super().__init__()
        self.cue_projection = nn.Linear(cue_size, hidden_size)
        self.gate = nn.Linear(hidden_size + cue_size, hidden_size)
        self.normalization = nn.LayerNorm(hidden_size)
        self.dropout = nn.Dropout(dropout)

    def forward(self, frames: torch.Tensor, cues: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if cues.shape[1] != frames.shape[1]:
            cues = F.interpolate(cues.transpose(1, 2), size=frames.shape[1], mode="linear", align_corners=False)
            cues = cues.transpose(1, 2)
        gate = torch.sigmoid(self.gate(torch.cat([frames, cues], dim=-1)))
        evidence = self.dropout(self.cue_projection(cues))
        fused = self.normalization(frames + gate * evidence)
        return fused, gate


class QualityAwareAttentiveStatisticsPooling(nn.Module):
    def __init__(self, hidden_size: int, quality_size: int = 4, attention_size: int = 256) -> None:
        super().__init__()
        self.frame_projection = nn.Linear(hidden_size, attention_size, bias=False)
        self.quality_projection = nn.Linear(quality_size, attention_size, bias=False)
        self.bias = nn.Parameter(torch.zeros(attention_size))
        self.score = nn.Linear(attention_size, 1, bias=False)

    def forward(
        self,
        frames: torch.Tensor,
        quality: torch.Tensor,
        frame_mask: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        energy = self.score(
            torch.tanh(
                self.frame_projection(frames)
                + self.quality_projection(quality).unsqueeze(1)
                + self.bias
            )
        ).squeeze(-1)
        if frame_mask is not None:
            energy = energy.masked_fill(~frame_mask.bool(), torch.finfo(energy.dtype).min)
        weights = torch.softmax(energy, dim=1)
        mean = torch.sum(weights.unsqueeze(-1) * frames, dim=1)
        variance = torch.sum(weights.unsqueeze(-1) * (frames - mean.unsqueeze(1)).square(), dim=1)
        deviation = torch.sqrt(variance.clamp_min(1e-6))
        return torch.cat([mean, deviation], dim=-1), weights


class MeanStatisticsPooling(nn.Module):
    def forward(
        self,
        frames: torch.Tensor,
        quality: torch.Tensor,
        frame_mask: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        del quality
        if frame_mask is None:
            weights = torch.full(
                frames.shape[:2],
                1.0 / frames.shape[1],
                device=frames.device,
                dtype=frames.dtype,
            )
        else:
            weights = frame_mask.to(frames.dtype)
            weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1.0)
        mean = torch.sum(weights.unsqueeze(-1) * frames, dim=1)
        variance = torch.sum(weights.unsqueeze(-1) * (frames - mean.unsqueeze(1)).square(), dim=1)
        return torch.cat([mean, torch.sqrt(variance.clamp_min(1e-6))], dim=-1), weights


@dataclass
class PENDOutput:
    logits: torch.Tensor
    dialect_representation: torch.Tensor
    pooled_representation: torch.Tensor
    segmental_representation: torch.Tensor
    suprasegmental_representation: torch.Tensor
    nuisance_representation: torch.Tensor
    speaker_logits: torch.Tensor
    prompt_logits: torch.Tensor
    fusion_gate: torch.Tensor
    attention_weights: torch.Tensor


class PENDCalNet(nn.Module):
    def __init__(
        self,
        encoder: nn.Module,
        hidden_size: int,
        class_count: int = 3,
        speaker_count: int = 1,
        prompt_count: int = 1,
        cue_size: int = 7,
        quality_size: int = 4,
        dialect_size: int = 512,
        evidence_size: int = 256,
        nuisance_size: int = 512,
        adversary_hidden_size: int = 256,
        dropout: float = 0.10,
        use_quality_pooling: bool = True,
    ) -> None:
        super().__init__()
        self.encoder = encoder
        self.class_count = class_count
        self.fusion = CounterfactualPhonologicalEvidenceFusion(hidden_size, cue_size, dropout)
        if use_quality_pooling:
            self.pooling = QualityAwareAttentiveStatisticsPooling(hidden_size, quality_size)
        else:
            self.pooling = MeanStatisticsPooling()
        pooled_size = 2 * hidden_size
        self.dialect_projection = nn.Sequential(
            nn.Linear(pooled_size, dialect_size),
            nn.LayerNorm(dialect_size),
            nn.GELU(),
        )
        self.classifier = nn.Linear(dialect_size, class_count)
        self.segmental_projection = nn.Linear(pooled_size, evidence_size)
        self.suprasegmental_projection = nn.Linear(pooled_size, evidence_size)
        self.nuisance_projection = nn.Sequential(
            nn.Linear(pooled_size, nuisance_size),
            nn.LayerNorm(nuisance_size),
            nn.GELU(),
        )
        adversary_input = nuisance_size + class_count
        self.speaker_adversary = nn.Sequential(
            nn.Linear(adversary_input, adversary_hidden_size),
            nn.GELU(),
            nn.Linear(adversary_hidden_size, max(1, speaker_count)),
        )
        self.prompt_adversary = nn.Sequential(
            nn.Linear(adversary_input, adversary_hidden_size),
            nn.GELU(),
            nn.Linear(adversary_hidden_size, max(1, prompt_count)),
        )

    @staticmethod
    def _normalize(values: torch.Tensor) -> torch.Tensor:
        return F.normalize(values, p=2, dim=-1)

    def forward_from_frames(
        self,
        frames: torch.Tensor,
        acoustic_cues: torch.Tensor,
        quality: torch.Tensor,
        frame_mask: torch.Tensor | None = None,
        labels: torch.Tensor | None = None,
        gradient_reversal: float = 0.0,
    ) -> PENDOutput:
        fused, gate = self.fusion(frames, acoustic_cues)
        pooled, attention = self.pooling(fused, quality, frame_mask)
        dialect = self.dialect_projection(pooled)
        logits = self.classifier(dialect)
        segmental = self._normalize(self.segmental_projection(pooled))
        suprasegmental = self._normalize(self.suprasegmental_projection(pooled))
        nuisance = self.nuisance_projection(pooled)
        condition = labels if labels is not None else logits.detach().argmax(dim=-1)
        one_hot = F.one_hot(condition, num_classes=self.class_count).to(nuisance.dtype)
        adversary_input = torch.cat([gradient_reverse(nuisance, gradient_reversal), one_hot], dim=-1)
        return PENDOutput(
            logits=logits,
            dialect_representation=dialect,
            pooled_representation=pooled,
            segmental_representation=segmental,
            suprasegmental_representation=suprasegmental,
            nuisance_representation=nuisance,
            speaker_logits=self.speaker_adversary(adversary_input),
            prompt_logits=self.prompt_adversary(adversary_input),
            fusion_gate=gate,
            attention_weights=attention,
        )

    def forward(
        self,
        input_values: torch.Tensor,
        attention_mask: torch.Tensor,
        acoustic_cues: torch.Tensor,
        quality: torch.Tensor,
        labels: torch.Tensor | None = None,
        gradient_reversal: float = 0.0,
    ) -> PENDOutput:
        frames, frame_mask = self.encoder(input_values, attention_mask)
        return self.forward_from_frames(
            frames,
            acoustic_cues,
            quality,
            frame_mask=frame_mask,
            labels=labels,
            gradient_reversal=gradient_reversal,
        )


class MarginQualityAdaptiveCalibrator(nn.Module):
    def __init__(self, quality_size: int = 5, hidden_size: int = 32, temperature_min: float = 0.25) -> None:
        super().__init__()
        self.temperature_min = float(temperature_min)
        self.network = nn.Sequential(
            nn.Linear(1 + quality_size, hidden_size),
            nn.GELU(),
            nn.Linear(hidden_size, 1),
        )

    def forward(
        self,
        logits: torch.Tensor,
        calibration_quality: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        top_two = logits.topk(k=2, dim=-1).values
        margin = (top_two[:, 0] - top_two[:, 1]).clamp_min(0.0).log1p().unsqueeze(-1)
        inputs = torch.cat([margin, calibration_quality], dim=-1)
        temperature = self.temperature_min + F.softplus(self.network(inputs)).squeeze(-1)
        calibrated_logits = logits / temperature.unsqueeze(-1)
        probabilities = torch.softmax(calibrated_logits, dim=-1)
        return probabilities, temperature

