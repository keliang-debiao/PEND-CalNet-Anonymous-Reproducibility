from __future__ import annotations

import hashlib

import torch

from .audio import add_deterministic_noise, pitch_flatten_world


def deterministic_track_dropout(tracks: torch.Tensor, fraction: float, record_key: str) -> torch.Tensor:
    if not 0.0 <= fraction <= 1.0:
        raise ValueError("fraction must be within [0, 1]")
    token = f"{record_key}|track_dropout|{fraction}|2026".encode("utf-8")
    seed = int.from_bytes(hashlib.sha256(token).digest()[:8], "big") % (2**63 - 1)
    generator = torch.Generator(device=tracks.device).manual_seed(seed)
    retain = torch.rand(tracks.shape[-1], generator=generator, device=tracks.device) >= fraction
    return tracks * retain.to(tracks.dtype)


def perturb_waveform(
    waveform: torch.Tensor,
    record_key: str,
    noise_snr_db: float | None = None,
    pitch_flatten_fraction: float | None = None,
) -> torch.Tensor:
    output = waveform
    if noise_snr_db is not None:
        output = add_deterministic_noise(output, noise_snr_db, record_key)
    if pitch_flatten_fraction is not None:
        output = pitch_flatten_world(output, fraction=pitch_flatten_fraction)
    return output
