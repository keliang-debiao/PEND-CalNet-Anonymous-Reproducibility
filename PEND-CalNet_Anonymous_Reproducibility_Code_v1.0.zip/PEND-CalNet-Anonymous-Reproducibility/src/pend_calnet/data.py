from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import StratifiedGroupKFold
from torch.utils.data import Dataset

from .audio import acoustic_tracks, load_mono, quality_descriptors, random_crop_or_pad


REQUIRED_COLUMNS = {
    "record_id",
    "corpus",
    "audio_path",
    "label",
    "speaker_id",
    "prompt_id",
}


def sha256_file(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def read_manifest(path: str | Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    missing = REQUIRED_COLUMNS.difference(frame.columns)
    if missing:
        raise ValueError(f"Manifest is missing columns: {sorted(missing)}")
    frame = frame.copy()
    frame["record_id"] = frame["record_id"].astype(str)
    frame["speaker_id"] = frame["speaker_id"].fillna("").astype(str)
    frame["prompt_id"] = frame["prompt_id"].fillna("").astype(str)
    return frame


def audit_manifest(frame: pd.DataFrame, require_speakers: bool) -> dict[str, Any]:
    duplicate_ids = int(frame["record_id"].duplicated().sum())
    duplicate_paths = int(frame["audio_path"].duplicated().sum())
    missing_paths = [p for p in frame["audio_path"] if not Path(p).is_file()]
    label_counts = frame["label"].value_counts().sort_index().to_dict()
    speaker_missing = int((frame["speaker_id"].str.len() == 0).sum())
    if require_speakers and speaker_missing:
        raise ValueError(f"Speaker identifiers missing for {speaker_missing} rows")
    if duplicate_ids or duplicate_paths or missing_paths:
        raise ValueError(
            f"Manifest audit failed: duplicate_ids={duplicate_ids}, "
            f"duplicate_paths={duplicate_paths}, missing_paths={len(missing_paths)}"
        )
    return {
        "rows": int(len(frame)),
        "class_counts": {str(k): int(v) for k, v in label_counts.items()},
        "speaker_count": int(frame.loc[frame["speaker_id"].str.len() > 0, "speaker_id"].nunique()),
        "prompt_count": int(frame.loc[frame["prompt_id"].str.len() > 0, "prompt_id"].nunique()),
        "duplicate_ids": duplicate_ids,
        "duplicate_paths": duplicate_paths,
        "missing_paths": len(missing_paths),
    }


def assign_outer_folds(frame: pd.DataFrame, folds: int = 5, seed: int = 2026) -> pd.DataFrame:
    if (frame["speaker_id"].str.len() == 0).any():
        raise ValueError("Outer-fold construction requires a speaker identifier for every row")
    labels = frame["label"].astype(str).to_numpy()
    groups = frame["speaker_id"].astype(str).to_numpy()
    splitter = StratifiedGroupKFold(n_splits=folds, shuffle=True, random_state=seed)
    assigned = np.full(len(frame), -1, dtype=np.int64)
    for fold, (_, test_index) in enumerate(splitter.split(frame, labels, groups), start=1):
        assigned[test_index] = fold
    if (assigned < 0).any():
        raise RuntimeError("Fold assignment did not cover every row")
    result = frame.copy()
    result["outer_fold"] = assigned
    return result


def split_outer_training_groups(
    frame: pd.DataFrame,
    outer_fold: int,
    inner_fraction: float,
    calibration_fraction: float,
    seed: int,
) -> pd.DataFrame:
    result = frame.copy()
    result["partition"] = np.where(result["outer_fold"] == outer_fold, "outer_test", "stage1_train")
    candidates = result[result["partition"] == "stage1_train"]
    speaker_table = candidates.groupby("speaker_id", as_index=False)["label"].agg(lambda x: x.mode().iat[0])
    rng = np.random.default_rng(seed)
    inner_groups: set[str] = set()
    calibration_groups: set[str] = set()
    for _, dialect_group in speaker_table.groupby("label"):
        speakers = dialect_group["speaker_id"].astype(str).to_numpy()
        rng.shuffle(speakers)
        inner_count = max(1, int(round(len(speakers) * inner_fraction)))
        calibration_count = max(1, int(round(len(speakers) * calibration_fraction)))
        inner_groups.update(speakers[:inner_count].tolist())
        calibration_groups.update(speakers[inner_count : inner_count + calibration_count].tolist())
    result.loc[result["speaker_id"].isin(inner_groups), "partition"] = "inner_validation"
    result.loc[result["speaker_id"].isin(calibration_groups), "partition"] = "source_calibration"
    return result


@dataclass(frozen=True)
class Record:
    record_id: str
    audio_path: str
    label: int
    speaker: int
    prompt: int


class TibetanDialectDataset(Dataset):
    def __init__(
        self,
        frame: pd.DataFrame,
        class_to_index: dict[str, int],
        sample_rate: int = 16000,
        window_seconds: float = 4.0,
        training: bool = True,
        seed: int = 2026,
        track_mean: torch.Tensor | None = None,
        track_std: torch.Tensor | None = None,
        quality_mean: torch.Tensor | None = None,
        quality_std: torch.Tensor | None = None,
    ) -> None:
        self.frame = frame.reset_index(drop=True).copy()
        self.class_to_index = class_to_index
        self.sample_rate = sample_rate
        self.width = int(round(window_seconds * sample_rate))
        self.training = training
        self.seed = seed
        self.speaker_map = {v: i for i, v in enumerate(sorted(self.frame["speaker_id"].astype(str).unique()))}
        self.prompt_map = {v: i for i, v in enumerate(sorted(self.frame["prompt_id"].astype(str).unique()))}
        self.track_mean = track_mean
        self.track_std = track_std
        self.quality_mean = quality_mean
        self.quality_std = quality_std

    def __len__(self) -> int:
        return len(self.frame)

    def __getitem__(self, index: int) -> dict[str, Any]:
        row = self.frame.iloc[index]
        waveform = load_mono(row.audio_path, self.sample_rate)
        generator = torch.Generator().manual_seed(self.seed * 1_000_003 + index)
        if self.training:
            waveform, attention_mask = random_crop_or_pad(waveform, self.width, generator)
        else:
            if waveform.numel() > self.width:
                waveform = waveform[: self.width]
                attention_mask = torch.ones(self.width, dtype=torch.long)
            else:
                attention_mask = torch.zeros(self.width, dtype=torch.long)
                attention_mask[: waveform.numel()] = 1
                waveform = torch.nn.functional.pad(waveform, (0, self.width - waveform.numel()))
        tracks = acoustic_tracks(waveform, self.sample_rate)
        quality = quality_descriptors(waveform, self.sample_rate)
        if self.track_mean is not None and self.track_std is not None:
            tracks = (tracks - self.track_mean) / self.track_std.clamp_min(1e-6)
        if self.quality_mean is not None and self.quality_std is not None:
            quality = (quality - self.quality_mean) / self.quality_std.clamp_min(1e-6)
        return {
            "record_id": str(row.record_id),
            "input_values": waveform,
            "attention_mask": attention_mask,
            "acoustic_cues": tracks,
            "quality": quality,
            "label": torch.tensor(self.class_to_index[str(row.label)], dtype=torch.long),
            "speaker": torch.tensor(self.speaker_map[str(row.speaker_id)], dtype=torch.long),
            "prompt": torch.tensor(self.prompt_map[str(row.prompt_id)], dtype=torch.long),
        }


def collate_records(batch: list[dict[str, Any]]) -> dict[str, Any]:
    tensor_keys = ["input_values", "attention_mask", "acoustic_cues", "quality", "label", "speaker", "prompt"]
    output: dict[str, Any] = {key: torch.stack([row[key] for row in batch]) for key in tensor_keys}
    output["record_id"] = [row["record_id"] for row in batch]
    return output
