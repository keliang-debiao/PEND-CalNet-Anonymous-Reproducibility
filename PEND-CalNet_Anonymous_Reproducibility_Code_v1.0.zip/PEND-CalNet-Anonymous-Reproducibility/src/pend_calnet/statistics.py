from __future__ import annotations

import numpy as np


def _metric_value(metric, probabilities: np.ndarray, labels: np.ndarray) -> float:
    return float(metric(probabilities, labels))


def cluster_bootstrap_interval(
    probabilities: np.ndarray,
    labels: np.ndarray,
    clusters: np.ndarray,
    metric,
    replicates: int = 2000,
    confidence: float = 0.95,
    seed: int = 2026,
) -> tuple[float, float]:
    clusters = np.asarray(clusters)
    unique = np.unique(clusters)
    rng = np.random.default_rng(seed)
    values = np.empty(replicates, dtype=np.float64)
    index_by_cluster = {cluster: np.flatnonzero(clusters == cluster) for cluster in unique}
    for replicate in range(replicates):
        selected = rng.choice(unique, size=len(unique), replace=True)
        index = np.concatenate([index_by_cluster[item] for item in selected])
        values[replicate] = _metric_value(metric, probabilities[index], labels[index])
    alpha = (1.0 - confidence) / 2.0
    low, high = np.quantile(values, [alpha, 1.0 - alpha])
    return float(low), float(high)


def dialect_stratified_bootstrap_interval(
    probabilities: np.ndarray,
    labels: np.ndarray,
    metric,
    replicates: int = 2000,
    confidence: float = 0.95,
    seed: int = 2026,
) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    groups = {label: np.flatnonzero(labels == label) for label in np.unique(labels)}
    values = np.empty(replicates, dtype=np.float64)
    for replicate in range(replicates):
        index = np.concatenate([rng.choice(rows, size=len(rows), replace=True) for rows in groups.values()])
        values[replicate] = _metric_value(metric, probabilities[index], labels[index])
    alpha = (1.0 - confidence) / 2.0
    low, high = np.quantile(values, [alpha, 1.0 - alpha])
    return float(low), float(high)


def paired_prediction_swap_test(
    probabilities_a: np.ndarray,
    probabilities_b: np.ndarray,
    labels: np.ndarray,
    metric,
    replicates: int = 10000,
    seed: int = 2026,
) -> tuple[float, float]:
    observed = _metric_value(metric, probabilities_a, labels) - _metric_value(metric, probabilities_b, labels)
    rng = np.random.default_rng(seed)
    null = np.empty(replicates, dtype=np.float64)
    for replicate in range(replicates):
        swap = rng.random(len(labels)) < 0.5
        first = probabilities_a.copy()
        second = probabilities_b.copy()
        first[swap], second[swap] = probabilities_b[swap], probabilities_a[swap]
        null[replicate] = _metric_value(metric, first, labels) - _metric_value(metric, second, labels)
    p_value = (1.0 + np.count_nonzero(np.abs(null) >= abs(observed))) / (replicates + 1.0)
    return float(observed), float(p_value)


def paired_bootstrap_difference_interval(
    probabilities_a: np.ndarray,
    probabilities_b: np.ndarray,
    labels: np.ndarray,
    metric,
    clusters: np.ndarray | None = None,
    replicates: int = 2000,
    confidence: float = 0.95,
    seed: int = 2026,
) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    values = np.empty(replicates, dtype=np.float64)
    if clusters is None:
        units = np.arange(len(labels))
        index_by_unit = {int(index): np.asarray([index]) for index in units}
    else:
        clusters = np.asarray(clusters)
        units = np.unique(clusters)
        index_by_unit = {unit: np.flatnonzero(clusters == unit) for unit in units}
    for replicate in range(replicates):
        selected = rng.choice(units, size=len(units), replace=True)
        index = np.concatenate([index_by_unit[unit] for unit in selected])
        values[replicate] = metric(probabilities_a[index], labels[index]) - metric(probabilities_b[index], labels[index])
    alpha = (1.0 - confidence) / 2.0
    low, high = np.quantile(values, [alpha, 1.0 - alpha])
    return float(low), float(high)


def holm_adjust(p_values: list[float]) -> list[float]:
    values = np.asarray(p_values, dtype=np.float64)
    order = np.argsort(values)
    adjusted_sorted = np.maximum.accumulate((len(values) - np.arange(len(values))) * values[order])
    adjusted = np.empty_like(values)
    adjusted[order] = np.minimum(adjusted_sorted, 1.0)
    return adjusted.tolist()


def paired_effect_size(values_a: np.ndarray, values_b: np.ndarray) -> float:
    difference = np.asarray(values_a, dtype=np.float64) - np.asarray(values_b, dtype=np.float64)
    deviation = difference.std(ddof=1)
    if deviation == 0:
        return float("inf") if difference.mean() != 0 else 0.0
    return float(difference.mean() / deviation)
