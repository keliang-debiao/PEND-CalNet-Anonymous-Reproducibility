from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


def configure_style() -> None:
    sns.set_theme(style="whitegrid", context="paper")
    plt.rcParams.update({"figure.dpi": 160, "savefig.dpi": 300, "font.family": "DejaVu Sans"})


def plot_fold_performance(frame: pd.DataFrame, output: Path) -> None:
    configure_style()
    rows = frame[frame["scope"] == "fold"].copy()
    long = rows.melt(id_vars=["fold"], value_vars=["macro_f1", "uar", "accuracy", "macro_auroc"])
    figure, axis = plt.subplots(figsize=(7.2, 4.2))
    sns.lineplot(data=long, x="fold", y="value", hue="variable", marker="o", ax=axis)
    axis.set(xlabel="Outer fold", ylabel="Score", ylim=(0.88, 0.99))
    figure.tight_layout()
    figure.savefig(output)
    plt.close(figure)


def plot_baselines(frame: pd.DataFrame, output: Path) -> None:
    configure_style()
    ordered = frame.sort_values("macro_f1")
    figure, axis = plt.subplots(figsize=(8.0, 5.4))
    sns.barplot(data=ordered, x="macro_f1", y="model", color="#3B82B8", ax=axis)
    axis.set(xlabel="Macro-F1", ylabel="Model", xlim=(0.70, 0.94))
    figure.tight_layout()
    figure.savefig(output)
    plt.close(figure)


def plot_external(frame: pd.DataFrame, output: Path) -> None:
    configure_style()
    figure, axis = plt.subplots(figsize=(7.5, 4.6))
    sns.barplot(data=frame, x="dataset", y="macro_f1", hue="model", ax=axis)
    axis.set(xlabel="External corpus", ylabel="Macro-F1", ylim=(0.68, 0.87))
    figure.tight_layout()
    figure.savefig(output)
    plt.close(figure)


def plot_ablation(frame: pd.DataFrame, output: Path) -> None:
    configure_style()
    long = frame.melt(id_vars=["variant"], value_vars=["internal_macro_f1", "slr149_macro_f1", "finance_macro_f1"])
    figure, axis = plt.subplots(figsize=(9.0, 5.1))
    sns.barplot(data=long, x="value", y="variant", hue="variable", ax=axis)
    axis.set(xlabel="Macro-F1", ylabel="Configuration", xlim=(0.70, 0.94))
    figure.tight_layout()
    figure.savefig(output)
    plt.close(figure)


def plot_calibration_robustness(calibration: pd.DataFrame, robustness: pd.DataFrame, output: Path) -> None:
    configure_style()
    figure, axes = plt.subplots(1, 2, figsize=(10.0, 4.2))
    sns.barplot(data=calibration, x="ece", y="method", color="#4E9F79", ax=axes[0])
    sns.barplot(data=robustness, x="macro_f1", y="condition", color="#C76D4B", ax=axes[1])
    axes[0].set(xlabel="ECE", ylabel="Calibration method")
    axes[1].set(xlabel="Macro-F1", ylabel="Stress condition", xlim=(0.68, 0.86))
    figure.tight_layout()
    figure.savefig(output)
    plt.close(figure)


def plot_statistics_interpretability(statistics: pd.DataFrame, auxiliary: pd.DataFrame, output: Path) -> None:
    configure_style()
    figure, axes = plt.subplots(1, 2, figsize=(10.2, 4.4))
    sns.pointplot(data=statistics, x="difference", y="comparison", color="#684A9E", ax=axes[0])
    gate = auxiliary[auxiliary["analysis"] == "mean_gate_by_condition"]
    sns.barplot(data=gate, x="value", y="condition", color="#D09A32", ax=axes[1])
    axes[0].set(xlabel="Paired difference", ylabel="Comparison")
    axes[1].set(xlabel="Mean gate", ylabel="Condition")
    figure.tight_layout()
    figure.savefig(output)
    plt.close(figure)
