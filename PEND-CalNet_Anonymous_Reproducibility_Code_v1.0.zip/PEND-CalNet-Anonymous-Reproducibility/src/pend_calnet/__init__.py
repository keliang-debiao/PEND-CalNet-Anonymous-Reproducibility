"""PEND-CalNet research implementation."""

from .config import load_config, seed_everything

__all__ = [
    "PENDCalNet",
    "MarginQualityAdaptiveCalibrator",
    "load_config",
    "seed_everything",
]

__version__ = "1.0.0"


def __getattr__(name: str):
    if name in {"PENDCalNet", "MarginQualityAdaptiveCalibrator"}:
        from .model import MarginQualityAdaptiveCalibrator, PENDCalNet

        return {"PENDCalNet": PENDCalNet, "MarginQualityAdaptiveCalibrator": MarginQualityAdaptiveCalibrator}[name]
    raise AttributeError(name)

