from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np
import pyworld
import torch
import torch.nn.functional as F
import torchaudio


def load_mono(path: str | Path, sample_rate: int = 16000) -> torch.Tensor:
    waveform, rate = torchaudio.load(str(path))
    waveform = waveform.mean(dim=0)
    if rate != sample_rate:
        waveform = torchaudio.functional.resample(waveform, rate, sample_rate)
    peak = waveform.abs().max().clamp_min(1e-8)
    if peak > 0.999:
        waveform = waveform * (0.999 / peak)
    return waveform.float()


def window_waveform(
    waveform: torch.Tensor,
    sample_rate: int,
    window_seconds: float,
    hop_seconds: float,
) -> list[tuple[torch.Tensor, torch.Tensor]]:
    width = int(round(window_seconds * sample_rate))
    hop = int(round(hop_seconds * sample_rate))
    if waveform.numel() <= width:
        valid = torch.zeros(width, dtype=torch.long)
        valid[: waveform.numel()] = 1
        return [(F.pad(waveform, (0, width - waveform.numel())), valid)]
    starts = list(range(0, waveform.numel() - width + 1, hop))
    if starts[-1] != waveform.numel() - width:
        starts.append(waveform.numel() - width)
    return [(waveform[s : s + width], torch.ones(width, dtype=torch.long)) for s in starts]


def random_crop_or_pad(
    waveform: torch.Tensor,
    width: int,
    generator: torch.Generator,
) -> tuple[torch.Tensor, torch.Tensor]:
    if waveform.numel() >= width:
        high = waveform.numel() - width + 1
        start = int(torch.randint(high, (1,), generator=generator).item())
        return waveform[start : start + width], torch.ones(width, dtype=torch.long)
    valid = torch.zeros(width, dtype=torch.long)
    valid[: waveform.numel()] = 1
    return F.pad(waveform, (0, width - waveform.numel())), valid


def _frame_signal(waveform: torch.Tensor, frame: int = 400, hop: int = 320) -> torch.Tensor:
    if waveform.numel() < frame:
        waveform = F.pad(waveform, (0, frame - waveform.numel()))
    return waveform.unfold(0, frame, hop)


def acoustic_tracks(waveform: torch.Tensor, sample_rate: int = 16000) -> torch.Tensor:
    frames = _frame_signal(waveform)
    window = torch.hann_window(frames.shape[-1], device=frames.device)
    centered = frames - frames.mean(dim=-1, keepdim=True)
    weighted = centered * window
    energy = weighted.square().mean(dim=-1).clamp_min(1e-10)
    log_energy = energy.log()

    min_lag = max(1, sample_rate // 400)
    max_lag = min(frames.shape[-1] - 1, sample_rate // 50)
    denom = centered.square().sum(dim=-1).clamp_min(1e-8)
    correlations = []
    for lag in range(min_lag, max_lag + 1):
        value = (centered[:, :-lag] * centered[:, lag:]).sum(dim=-1) / denom
        correlations.append(value)
    corr = torch.stack(correlations, dim=-1)
    peak_corr, peak_index = corr.max(dim=-1)
    lag = peak_index + min_lag
    f0 = sample_rate / lag.float()
    voiced = peak_corr.clamp(0.0, 1.0)
    missing = voiced < 0.30
    log_f0 = f0.clamp_min(1.0).log()
    utterance_mean = log_f0.masked_fill(missing, 0.0).sum() / (~missing).sum().clamp_min(1)
    log_f0 = torch.where(missing, utterance_mean, log_f0)
    delta = F.pad(log_f0[1:] - log_f0[:-1], (1, 0))
    hnr = 10.0 * torch.log10(voiced.clamp_min(1e-4) / (1.0 - voiced).clamp_min(1e-4))

    spectrum = torch.fft.rfft(weighted, dim=-1).abs().clamp_min(1e-8).log()
    frequency = torch.linspace(-1.0, 1.0, spectrum.shape[-1], device=spectrum.device)
    frequency = frequency - frequency.mean()
    slope = (spectrum * frequency).sum(dim=-1) / frequency.square().sum().clamp_min(1e-8)

    return torch.stack(
        [log_f0, delta, voiced, log_energy, hnr, slope, missing.float()],
        dim=-1,
    )


def quality_descriptors(waveform: torch.Tensor, sample_rate: int = 16000) -> torch.Tensor:
    duration = waveform.numel() / float(sample_rate)
    frames = _frame_signal(waveform)
    energy = frames.square().mean(dim=-1).clamp_min(1e-10)
    high = torch.quantile(energy, 0.90)
    low = torch.quantile(energy, 0.10).clamp_min(1e-10)
    snr = 10.0 * torch.log10(high / low)
    tracks = acoustic_tracks(waveform, sample_rate)
    voiced_rate = (tracks[:, 6] < 0.5).float().mean()
    clipping_rate = (waveform.abs() >= 0.999).float().mean()
    return torch.stack(
        [
            torch.tensor(duration, device=waveform.device).clamp_min(1e-4).log(),
            snr,
            voiced_rate,
            clipping_rate.clamp_min(1e-8).log1p(),
        ]
    )


def pitch_flatten_world(
    waveform: torch.Tensor,
    sample_rate: int = 16000,
    fraction: float = 1.0,
) -> torch.Tensor:
    if not 0.0 <= fraction <= 1.0:
        raise ValueError("fraction must be within [0, 1]")
    audio = waveform.detach().cpu().double().numpy()
    f0, time_axis = pyworld.dio(audio, sample_rate)
    f0 = pyworld.stonemask(audio, f0, time_axis, sample_rate)
    spectral = pyworld.cheaptrick(audio, f0, time_axis, sample_rate)
    aperiodicity = pyworld.d4c(audio, f0, time_axis, sample_rate)
    voiced = f0 > 0
    if voiced.any():
        log_f0 = np.log(np.maximum(f0[voiced], 1e-8))
        target = log_f0.mean()
        adjusted = (1.0 - fraction) * log_f0 + fraction * target
        f0 = f0.copy()
        f0[voiced] = np.exp(adjusted)
    output = pyworld.synthesize(f0, spectral, aperiodicity, sample_rate)
    output = torch.from_numpy(output).float()
    if output.numel() < waveform.numel():
        output = F.pad(output, (0, waveform.numel() - output.numel()))
    return output[: waveform.numel()]


def add_deterministic_noise(
    waveform: torch.Tensor,
    snr_db: float,
    record_key: str,
) -> torch.Tensor:
    token = f"{record_key}|noise|{snr_db}|2026".encode("utf-8")
    seed = int.from_bytes(hashlib.sha256(token).digest()[:8], "big") % (2**63 - 1)
    generator = torch.Generator(device=waveform.device).manual_seed(seed)
    noise = torch.randn(waveform.shape, generator=generator, device=waveform.device)
    signal_power = waveform.square().mean().clamp_min(1e-12)
    noise_power = noise.square().mean().clamp_min(1e-12)
    scale = torch.sqrt(signal_power / (noise_power * (10.0 ** (snr_db / 10.0))))
    output = waveform + scale * noise
    peak = output.abs().max().clamp_min(1e-8)
    if peak > 0.999:
        output = output * (0.999 / peak)
    return output

