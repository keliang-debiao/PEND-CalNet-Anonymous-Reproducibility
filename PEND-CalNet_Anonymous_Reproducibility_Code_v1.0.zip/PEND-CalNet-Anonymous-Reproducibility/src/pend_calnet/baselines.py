from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_sample_weight


@dataclass(frozen=True)
class BaselineSpec:
    name: str
    estimator: object


def traditional_baselines(seed: int = 2026) -> list[BaselineSpec]:
    models: list[BaselineSpec] = [
        BaselineSpec(
            "logistic_regression",
            Pipeline(
                [
                    ("scale", StandardScaler()),
                    ("model", LogisticRegression(C=1.0, max_iter=4000, class_weight="balanced")),
                ]
            ),
        ),
        BaselineSpec(
            "random_forest",
            RandomForestClassifier(
                n_estimators=500,
                max_features="sqrt",
                min_samples_leaf=2,
                class_weight="balanced_subsample",
                n_jobs=-1,
                random_state=seed,
            ),
        ),
    ]
    try:
        from xgboost import XGBClassifier

        models.append(
            BaselineSpec(
                "xgboost",
                XGBClassifier(
                    n_estimators=600,
                    max_depth=6,
                    learning_rate=0.05,
                    subsample=0.8,
                    colsample_bytree=0.8,
                    objective="multi:softprob",
                    eval_metric="mlogloss",
                    n_jobs=-1,
                    random_state=seed,
                ),
            )
        )
    except ImportError:
        pass
    return models


def fit_baseline(spec: BaselineSpec, train_x: np.ndarray, train_y: np.ndarray):
    if spec.name == "xgboost":
        weights = compute_sample_weight(class_weight="balanced", y=train_y)
        return spec.estimator.fit(train_x, train_y, sample_weight=weights)
    return spec.estimator.fit(train_x, train_y)
