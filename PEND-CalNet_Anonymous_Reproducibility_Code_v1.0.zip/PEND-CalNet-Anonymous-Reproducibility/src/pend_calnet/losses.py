from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn.functional as F

from .model import PENDOutput


def weighted_classification_loss(
    logits: torch.Tensor,
    labels: torch.Tensor,
    class_weights: torch.Tensor,
) -> torch.Tensor:
    return F.cross_entropy(logits, labels, weight=class_weights)


def phonological_evidence_loss(
    original: PENDOutput,
    flattened: PENDOutput,
    response_margin: float,
    response_weight: float,
) -> torch.Tensor:
    stable = 1.0 - F.cosine_similarity(
        original.segmental_representation,
        flattened.segmental_representation,
        dim=-1,
    )
    response = torch.linalg.vector_norm(
        original.suprasegmental_representation - flattened.suprasegmental_representation,
        dim=-1,
    )
    bounded = F.relu(response_margin - response).square()
    return (stable + response_weight * bounded).mean()


def covariance_orthogonality_loss(
    dialect: torch.Tensor,
    nuisance: torch.Tensor,
) -> torch.Tensor:
    dialect = dialect - dialect.mean(dim=0, keepdim=True)
    nuisance = nuisance - nuisance.mean(dim=0, keepdim=True)
    denominator = max(1, dialect.shape[0] - 1)
    cross_covariance = dialect.transpose(0, 1) @ nuisance / denominator
    return cross_covariance.square().sum()


def nuisance_disentanglement_loss(
    output: PENDOutput,
    speaker_targets: torch.Tensor,
    prompt_targets: torch.Tensor,
    shared_prompt_mask: torch.Tensor,
    prompt_weight: float,
    orthogonality_weight: float,
) -> torch.Tensor:
    speaker = F.cross_entropy(output.speaker_logits, speaker_targets)
    if shared_prompt_mask.any():
        prompt = F.cross_entropy(
            output.prompt_logits[shared_prompt_mask],
            prompt_targets[shared_prompt_mask],
        )
    else:
        prompt = output.prompt_logits.sum() * 0.0
    orthogonality = covariance_orthogonality_loss(
        output.dialect_representation,
        output.nuisance_representation,
    )
    return speaker + prompt_weight * prompt + orthogonality_weight * orthogonality


def cross_speaker_supervised_contrastive_loss(
    representation: torch.Tensor,
    labels: torch.Tensor,
    speakers: torch.Tensor,
    prompts: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    values = F.normalize(representation, dim=-1)
    similarity = values @ values.transpose(0, 1) / temperature
    identity = torch.eye(values.shape[0], dtype=torch.bool, device=values.device)
    positive = (
        (labels[:, None] == labels[None, :])
        & (speakers[:, None] != speakers[None, :])
        & (prompts[:, None] != prompts[None, :])
        & ~identity
    )
    valid = positive.any(dim=1)
    if not valid.any():
        return similarity.sum() * 0.0
    denominator_mask = ~identity
    log_denominator = torch.logsumexp(
        similarity.masked_fill(~denominator_mask, torch.finfo(similarity.dtype).min),
        dim=1,
    )
    positive_log = torch.logsumexp(
        similarity.masked_fill(~positive, torch.finfo(similarity.dtype).min),
        dim=1,
    )
    return -(positive_log[valid] - log_denominator[valid]).mean()


def symmetric_consistency_loss(logits_a: torch.Tensor, logits_b: torch.Tensor) -> torch.Tensor:
    log_a = F.log_softmax(logits_a, dim=-1)
    log_b = F.log_softmax(logits_b, dim=-1)
    prob_a = log_a.exp()
    prob_b = log_b.exp()
    return 0.5 * (
        F.kl_div(log_a, prob_b, reduction="batchmean")
        + F.kl_div(log_b, prob_a, reduction="batchmean")
    )


def soft_calibration_error(
    probabilities: torch.Tensor,
    labels: torch.Tensor,
    bins: int = 15,
    bandwidth: float = 0.05,
    epsilon: float = 0.001,
) -> torch.Tensor:
    confidence, prediction = probabilities.max(dim=-1)
    correct = (prediction == labels).to(probabilities.dtype)
    centers = torch.linspace(0.0, 1.0, bins, device=probabilities.device, dtype=probabilities.dtype)
    weights = torch.exp(-((confidence[:, None] - centers[None, :]) ** 2) / (2.0 * bandwidth**2))
    weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1e-8)
    mass = weights.sum(dim=0).clamp_min(1e-8)
    accuracy = (weights * correct[:, None]).sum(dim=0) / mass
    mean_confidence = (weights * confidence[:, None]).sum(dim=0) / mass
    gap = torch.sqrt((accuracy - mean_confidence).square() + epsilon**2)
    return ((mass / probabilities.shape[0]) * gap).sum()


@dataclass
class LossBundle:
    total: torch.Tensor
    classification: torch.Tensor
    phonological: torch.Tensor
    nuisance: torch.Tensor
    contrastive: torch.Tensor
    consistency: torch.Tensor


def total_training_loss(
    output_a: PENDOutput,
    output_b: PENDOutput,
    output_flattened: PENDOutput,
    labels: torch.Tensor,
    speakers: torch.Tensor,
    prompts: torch.Tensor,
    shared_prompt_mask: torch.Tensor,
    class_weights: torch.Tensor,
    weights: dict[str, float],
    response_margin: float,
) -> LossBundle:
    classification = weighted_classification_loss(output_a.logits, labels, class_weights)
    phonological = phonological_evidence_loss(
        output_a,
        output_flattened,
        response_margin=response_margin,
        response_weight=weights["response_weight"],
    )
    nuisance = nuisance_disentanglement_loss(
        output_a,
        speakers,
        prompts,
        shared_prompt_mask,
        prompt_weight=weights["prompt_weight"],
        orthogonality_weight=weights["orthogonality_weight"],
    )
    contrastive = cross_speaker_supervised_contrastive_loss(
        output_a.dialect_representation,
        labels,
        speakers,
        prompts,
        temperature=weights["contrastive_temperature"],
    )
    consistency = symmetric_consistency_loss(output_a.logits, output_b.logits)
    total = (
        classification
        + weights["phonological_evidence"] * phonological
        + weights["nuisance_disentanglement"] * nuisance
        + weights["supervised_contrastive"] * contrastive
        + weights["augmentation_consistency"] * consistency
    )
    return LossBundle(total, classification, phonological, nuisance, contrastive, consistency)
