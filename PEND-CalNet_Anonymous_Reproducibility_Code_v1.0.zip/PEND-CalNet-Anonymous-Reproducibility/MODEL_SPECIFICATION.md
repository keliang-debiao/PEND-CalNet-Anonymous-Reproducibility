# PEND-CalNet Implementation Contract

## Tensor interface

At 16 kHz, each training item is a four-second waveform tensor of shape `[B, 64000]` with a sample mask of the same shape. The acoustic-track extractor produces `[B, T_a, 7]` values in this order: log fundamental frequency, pitch change, voicing strength, log energy, harmonic-to-noise ratio, spectral slope, and missing-pitch indicator. Four utterance-quality descriptors encode log duration, an energy-based signal-to-noise proxy, voiced-frame proportion, and clipping proportion.

All acoustic-track and quality statistics are fitted on the active source-training partition. Inner validation, source calibration, outer test, and external corpora receive only the stored source transformation.

## Forward path

1. XLS-R-300M maps the waveform to contextual frame states. Base weights remain frozen; rank-8 LoRA adapters are inserted only in transformer blocks 13–24.
2. Counterfactual phonological evidence fusion projects the seven acoustic tracks and applies a content-dependent gate before residual normalization.
3. Quality-aware attentive statistics pooling uses the four quality descriptors to condition frame weights and concatenates weighted means and standard deviations.
4. A 512-dimensional dialect representation produces three logits ordered as `u_tsang`, `amdo`, and `kham`.
5. Frozen logits, the top-two margin, standardized quality descriptors, and a shrinkage-Mahalanobis source distance enter MQAC. Its positive sample-specific temperature produces the final probability vector.

Overlapping four-second inference windows use a two-second hop. Window logits, representations, quality vectors, and gate summaries are averaged at utterance level before calibration. Seed probabilities are then averaged before metric calculation.

## Training-only paths

The segmental and suprasegmental projections, pitch-flattened counterfactual branch, conditional speaker and prompt adversaries, covariance penalty, cross-speaker contrastive objective, and paired augmentation branch are used only while fitting the source encoder and prediction head. They do not add inputs to deployment-time inference.

The stage-one objective is the sum of class-weighted dialect cross-entropy and four weighted terms: phonological counterfactual evidence, nuisance disentanglement, supervised contrastive learning, and augmentation consistency. MQAC is fitted only after the stage-one checkpoint is frozen. External labels never enter parameter estimation, preprocessing, threshold choice, or calibration.

## Stored checkpoint state

Each checkpoint contains model and calibrator parameters, source normalization, source moments, the resolved search configuration, variant flags, seed, selected epoch, and source speaker/prompt head sizes. The checkpoint therefore reconstructs the exact tensor architecture even when fold-level search selected a nondefault LoRA rank or loss weight.
