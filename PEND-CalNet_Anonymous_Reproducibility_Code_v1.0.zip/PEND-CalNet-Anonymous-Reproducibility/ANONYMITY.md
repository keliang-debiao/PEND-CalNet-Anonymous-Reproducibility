# Anonymous Review Checklist

- No author names, affiliations, email addresses, funding identifiers, or acknowledgments are stored.
- No absolute paths from the development machines are stored.
- Commit history is excluded from the submitted archive.
- Audio files and provider metadata are excluded.
- Prediction records use corpus-local identifiers only.
- Machine names and user names are removed from reference run records.
- The archive can be assigned a review-only repository URL without modification.

