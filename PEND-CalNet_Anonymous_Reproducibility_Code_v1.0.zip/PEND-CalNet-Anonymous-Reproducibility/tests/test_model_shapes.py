import torch
import torch.nn as nn

from pend_calnet.model import MarginQualityAdaptiveCalibrator, PENDCalNet


class FixedEncoder(nn.Module):
    def __init__(self, hidden_size: int = 24, frames: int = 16) -> None:
        super().__init__()
        self.hidden_size = hidden_size
        self.frames = frames
        self.project = nn.Linear(1, hidden_size)

    def forward(self, input_values: torch.Tensor, attention_mask: torch.Tensor):
        pooled = input_values[:, : self.frames].unsqueeze(-1)
        frames = self.project(pooled)
        mask = attention_mask[:, : self.frames].bool()
        return frames, mask


def test_end_to_end_shapes() -> None:
    model = PENDCalNet(
        FixedEncoder(),
        hidden_size=24,
        speaker_count=5,
        prompt_count=7,
        dialect_size=32,
        evidence_size=12,
        nuisance_size=16,
        adversary_hidden_size=10,
    )
    output = model(
        torch.randn(4, 64),
        torch.ones(4, 64, dtype=torch.long),
        torch.randn(4, 16, 7),
        torch.randn(4, 4),
        labels=torch.tensor([0, 1, 2, 0]),
        gradient_reversal=0.5,
    )
    assert output.logits.shape == (4, 3)
    assert output.dialect_representation.shape == (4, 32)
    assert output.speaker_logits.shape == (4, 5)
    assert output.prompt_logits.shape == (4, 7)


def test_calibrator_outputs_probabilities() -> None:
    module = MarginQualityAdaptiveCalibrator(quality_size=5, hidden_size=8)
    probabilities, temperature = module(torch.randn(6, 3), torch.randn(6, 5))
    assert probabilities.shape == (6, 3)
    assert temperature.shape == (6,)
    assert torch.allclose(probabilities.sum(dim=1), torch.ones(6), atol=1e-6)
    assert (temperature >= 0.25).all()
