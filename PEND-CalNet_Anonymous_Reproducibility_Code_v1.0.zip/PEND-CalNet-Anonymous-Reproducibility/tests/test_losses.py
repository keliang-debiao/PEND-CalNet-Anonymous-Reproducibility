import torch

from pend_calnet.losses import covariance_orthogonality_loss, soft_calibration_error, symmetric_consistency_loss


def test_consistency_is_zero_for_identical_logits() -> None:
    logits = torch.randn(8, 3)
    assert torch.isclose(symmetric_consistency_loss(logits, logits), torch.tensor(0.0), atol=1e-6)


def test_auxiliary_losses_are_finite() -> None:
    dialect = torch.randn(8, 16)
    nuisance = torch.randn(8, 12)
    probabilities = torch.softmax(torch.randn(8, 3), dim=1)
    labels = torch.tensor([0, 1, 2, 0, 1, 2, 0, 1])
    assert torch.isfinite(covariance_orthogonality_loss(dialect, nuisance))
    assert torch.isfinite(soft_calibration_error(probabilities, labels))
