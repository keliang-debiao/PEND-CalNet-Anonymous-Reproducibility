from pathlib import Path

from pend_calnet.config import apply_selected_parameters, config_digest, load_config


def test_configuration_is_stable() -> None:
    config = load_config(Path("configs/pend_calnet.yaml"))
    first = config_digest(config)
    second = config_digest(load_config(Path("configs/pend_calnet.yaml")))
    assert first == second


def test_selected_parameters_reach_expected_sections() -> None:
    config = load_config(Path("configs/pend_calnet.yaml"))
    updated = apply_selected_parameters(config, {"lora_rank": 4, "new_layer_lr": 0.0001, "phonological_evidence": 0.2})
    assert updated["encoder"]["lora"]["rank"] == 4
    assert updated["optimization"]["new_layer_lr"] == 0.0001
    assert updated["loss"]["phonological_evidence"] == 0.2
