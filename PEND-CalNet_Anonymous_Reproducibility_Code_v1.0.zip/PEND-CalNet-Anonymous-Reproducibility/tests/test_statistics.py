import numpy as np

from pend_calnet.statistics import holm_adjust, paired_effect_size


def test_holm_adjustment_order_and_bounds() -> None:
    raw = [0.01, 0.04, 0.02]
    adjusted = holm_adjust(raw)
    assert all(0.0 <= value <= 1.0 for value in adjusted)
    assert all(after >= before for before, after in zip(raw, adjusted))


def test_paired_effect_size_sign() -> None:
    first = np.asarray([0.9, 0.8, 0.7, 0.6])
    second = np.asarray([0.7, 0.7, 0.6, 0.5])
    assert paired_effect_size(first, second) > 0
