import numpy as np

from pend_calnet.metrics import classification_metrics, equal_frequency_ece, mean_sd_t_ci, multiclass_brier


def test_metric_bounds_and_identity() -> None:
    probabilities = np.asarray([[0.8, 0.1, 0.1], [0.1, 0.7, 0.2], [0.2, 0.2, 0.6]])
    labels = np.asarray([0, 1, 2])
    bundle = classification_metrics(probabilities, labels, bins=3)
    assert bundle.macro_f1 == 1.0
    assert bundle.uar == 1.0
    assert bundle.accuracy == 1.0
    assert 0.0 <= equal_frequency_ece(probabilities, labels, 3) <= 1.0
    assert multiclass_brier(probabilities, labels) >= 0.0


def test_t_interval_contains_mean() -> None:
    mean, sd, low, high = mean_sd_t_ci(np.asarray([0.914, 0.921, 0.907, 0.923, 0.916]))
    assert low < mean < high
    assert sd > 0
