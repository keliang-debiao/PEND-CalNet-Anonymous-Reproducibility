# Baseline Protocol

## Shared controls

All baselines use the immutable outer-fold column created by `build_folds.py`. Preprocessing, acoustic-summary fitting, early stopping, model selection, and calibration are performed separately inside each outer-training partition. Outer-test probabilities are never used for fitting. Randomness is controlled by the same seed set used for PEND-CalNet.

## Model families

- Logistic regression, random forest, XGBoost, and MLP consume eGeMAPSv02 functionals extracted by openSMILE.
- Log-Mel CNN, CRNN, ECAPA-TDNN, and Conformer consume 80-bin log-Mel features derived from the same waveform windows.
- wav2vec 2.0, WavLM Base+, XEUS, XLS-R linear, and XLS-R attentive use the checkpoints and LoRA settings in `configs/baselines.yaml`.

Neural baselines use class-weighted cross-entropy, inner-validation Macro-F1 for early stopping, AdamW, gradient clipping at 1.0, and source-calibration temperature fitting. The matched XLS-R controls isolate the effect of the proposed phonological, nuisance, pooling, contrastive, and calibration mechanisms from the pretrained backbone.

## Reporting contract

Each baseline run emits record-level probabilities and a metric JSON file. Five-fold summaries use the sample SD across folds and a two-sided Student t interval. Paired tests operate on aligned prediction records, with Holm adjustment applied within the prespecified comparison family. Published Tibetan results remain contextual when their task, split, or metric differs from the current protocol.
