# Public Data Access

## TIBMD@MUC

- Role: development and internal validation
- Provider: OpenSLR SLR124
- Landing page: https://www.openslr.org/124/
- License: CC BY-SA 4.0
- Manuscript audit target: 68,466 utterances, 84.33 h, three dialect labels

## Tibetan Greetings

- Role: external validation 1
- Provider: OpenSLR SLR149
- Landing page: https://www.openslr.org/149/
- License: CC BY-SA 4.0
- Manuscript audit target: 3,000 recordings, 30 speakers, 1,000 recordings per dialect

## TibSpeech-3D Finance

- Role: external validation 2
- Provider: Open Science Framework
- Persistent identifier: https://doi.org/10.17605/OSF.IO/U6HFS
- License: CC BY 4.0
- Manuscript audit target: 500 Finance utterances with class counts 166, 166, and 168

## Access boundary

The repository does not mirror audio, transcripts, or released metadata. Users must obtain the data from the original providers and comply with the stated licenses. No credentialed-access or privately authorized corpus is required by the study design.

