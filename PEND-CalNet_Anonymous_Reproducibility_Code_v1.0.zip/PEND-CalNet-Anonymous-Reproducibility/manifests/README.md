# Manifest contract

The pipeline never discovers records during model fitting. Each corpus is converted once into a CSV manifest and then audited before fold creation.

Required columns:

| Column | Meaning |
|---|---|
| `record_id` | Corpus-scoped stable record identifier |
| `corpus` | Corpus identifier |
| `audio_path` | Absolute path to a released audio file |
| `label` | One of `u_tsang`, `amdo`, or `kham` |
| `speaker_id` | Released or path-derived speaker identifier; empty only where the release provides none |
| `prompt_id` | Released or filename-derived prompt identifier |
| `duration_seconds` | Duration read from the audio header |
| `sample_rate` | Sampling rate read from the audio header |
| `sha256` | File-content digest |

`build_folds.py` adds `outer_fold` and `partition` only after the development manifest passes the audit. Absolute audio paths are local inputs and are excluded from version control.
