# Results Provenance

## Two non-interchangeable record classes

`results/reference_records/` and `logs/` contain manuscript-aligned targets. Their role is to let a reproducer verify schemas, rounding, arithmetic, output ordering, and expected stopping behavior before the public corpora and pretrained weights are available locally. Every such record is marked `execution_verified=false`.

`artifacts/` is reserved for machine-generated outputs. Training scripts write the resolved configuration, split assignments, training history, checkpoint, prediction probabilities, metrics, and environment-dependent profiling data to that location. Reproduced claims must be based on these outputs, not on the reference records.

## Required promotion checks

A local run may be treated as reproduced evidence only after all of the following are retained:

1. corpus manifest and audio-content digests;
2. fold and source-partition assignments;
3. resolved configuration and seed;
4. checkpoint digest and selected epoch;
5. record-level logits or probabilities;
6. calibration state fitted only on source-calibration speakers;
7. bootstrap and permutation settings;
8. software and accelerator inventory;
9. successful package verification and unit tests.

Reference records remain unchanged after local reproduction so that discrepancies can be inspected directly.
