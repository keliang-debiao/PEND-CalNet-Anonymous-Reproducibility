#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score

from pend_calnet.statistics import holm_adjust, paired_bootstrap_difference_interval, paired_effect_size, paired_prediction_swap_test


PROBABILITY_COLUMNS = ["prob_u_tsang", "prob_amdo", "prob_kham"]


def macro_f1(probabilities: np.ndarray, labels: np.ndarray) -> float:
    return float(f1_score(labels, probabilities.argmax(axis=1), average="macro"))


def load_aligned(path: Path, identifiers: pd.Series | None = None) -> pd.DataFrame:
    frame = pd.read_csv(path).sort_values("record_id").reset_index(drop=True)
    if identifiers is not None and not frame["record_id"].equals(identifiers):
        raise ValueError(f"Record identifiers do not align: {path}")
    return frame


def main() -> None:
    parser = argparse.ArgumentParser(description="Run paired prediction-swap tests")
    parser.add_argument("--candidate", required=True, type=Path)
    parser.add_argument("--comparator", required=True, action="append", help="NAME=CSV_PATH")
    parser.add_argument("--replicates", type=int, default=10000)
    parser.add_argument("--bootstrap-replicates", type=int, default=2000)
    parser.add_argument("--cluster-column")
    parser.add_argument("--output", type=Path, default=Path("artifacts/analysis/statistical_tests.csv"))
    args = parser.parse_args()
    candidate = load_aligned(args.candidate)
    candidate_probabilities = candidate[PROBABILITY_COLUMNS].to_numpy()
    labels = candidate["label"].to_numpy()
    rows, p_values = [], []
    for item in args.comparator:
        name, raw_path = item.split("=", 1)
        comparator = load_aligned(Path(raw_path), candidate["record_id"])
        difference, p_value = paired_prediction_swap_test(
            candidate_probabilities,
            comparator[PROBABILITY_COLUMNS].to_numpy(),
            labels,
            macro_f1,
            replicates=args.replicates,
        )
        clusters = candidate[args.cluster_column].to_numpy() if args.cluster_column else None
        ci_low, ci_high = paired_bootstrap_difference_interval(
            candidate_probabilities,
            comparator[PROBABILITY_COLUMNS].to_numpy(),
            labels,
            macro_f1,
            clusters=clusters,
            replicates=args.bootstrap_replicates,
        )
        paired_indicator_a = (candidate_probabilities.argmax(axis=1) == labels).astype(float)
        paired_indicator_b = (comparator[PROBABILITY_COLUMNS].to_numpy().argmax(axis=1) == labels).astype(float)
        rows.append(
            {
                "comparison": name,
                "difference": difference,
                "ci_low": ci_low,
                "ci_high": ci_high,
                "p_raw": p_value,
                "effect_dz": paired_effect_size(paired_indicator_a, paired_indicator_b),
            }
        )
        p_values.append(p_value)
    adjusted = holm_adjust(p_values)
    for row, value in zip(rows, adjusted):
        row["p_holm"] = value
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(args.output, index=False)
    print(args.output.as_posix())


if __name__ == "__main__":
    main()
