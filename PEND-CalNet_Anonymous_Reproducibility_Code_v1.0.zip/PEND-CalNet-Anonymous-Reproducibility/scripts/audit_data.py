#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import yaml

from pend_calnet.config import load_config
from pend_calnet.data import audit_manifest, read_manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Audit all configured corpus manifests")
    parser.add_argument("--config", required=True, type=Path)
    args = parser.parse_args()
    config = load_config(args.config)
    paths = {"tibmd": config["data"]["development_manifest"], **config["data"]["external_manifests"]}
    report = {}
    digests: dict[str, set[str]] = {}
    for corpus, path in paths.items():
        frame = read_manifest(path)
        report[corpus] = audit_manifest(frame, require_speakers=corpus != "finance")
        dataset_config = yaml.safe_load((Path("configs/datasets") / f"{corpus}.yaml").read_text(encoding="utf-8"))
        expected = dataset_config.get("expected_utterances")
        if expected is not None and len(frame) != int(expected):
            raise ValueError(f"{corpus}: expected {expected} records but found {len(frame)}")
        counts = {str(key): int(value) for key, value in frame["label"].value_counts().to_dict().items()}
        if counts != {str(key): int(value) for key, value in dataset_config["expected_class_counts"].items()}:
            raise ValueError(f"{corpus}: class counts differ from the recorded release counts")
        if "sha256" not in frame:
            raise ValueError(f"{corpus}: manifest does not contain audio SHA-256 values")
        digests[corpus] = set(frame["sha256"].astype(str))
    corpus_names = list(digests)
    for left_index, left in enumerate(corpus_names):
        for right in corpus_names[left_index + 1 :]:
            overlap = digests[left] & digests[right]
            if overlap:
                raise ValueError(f"Cross-corpus audio overlap detected between {left} and {right}: {len(overlap)} files")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
