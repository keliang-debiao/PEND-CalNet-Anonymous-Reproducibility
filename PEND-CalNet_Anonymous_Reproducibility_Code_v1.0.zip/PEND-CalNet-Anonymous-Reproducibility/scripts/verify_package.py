#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
import yaml


ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "results" / "reference_records"


def require_paths() -> None:
    required = [
        "README.md",
        "REPRODUCIBILITY.md",
        "DATA_ACCESS.md",
        "ANONYMITY.md",
        "LICENSE",
        "pyproject.toml",
        "requirements.txt",
        "environment.yml",
        "configs/pend_calnet.yaml",
        "src/pend_calnet/model.py",
        "src/pend_calnet/losses.py",
        "src/pend_calnet/calibration.py",
        "scripts/train_cv.py",
        "scripts/fit_final.py",
        "scripts/evaluate_external.py",
        "scripts/run_statistics.py",
    ]
    missing = [item for item in required if not (ROOT / item).is_file()]
    if missing:
        raise AssertionError(f"Required files missing: {missing}")


def verify_config() -> None:
    config = yaml.safe_load((ROOT / "configs/pend_calnet.yaml").read_text(encoding="utf-8"))
    assert config["project"]["name"] == "PEND-CalNet"
    assert config["data"]["outer_folds"] == 5
    assert config["project"]["seeds"] == [2026, 2027, 2028]
    assert config["encoder"]["checkpoint"] == "facebook/wav2vec2-xls-r-300m"
    assert set(config["project"]["class_to_index"].values()) == {0, 1, 2}


def verify_fold_arithmetic() -> None:
    frame = pd.read_csv(REFERENCE / "fold_metrics.csv")
    folds = frame[frame["scope"] == "fold"]
    mean = frame[frame["scope"] == "mean"].iloc[0]
    sd = frame[frame["scope"] == "sd"].iloc[0]
    for column in ["macro_f1", "uar", "accuracy", "macro_auroc", "ece", "brier"]:
        if round(float(folds[column].mean()), 3) != round(float(mean[column]), 3):
            raise AssertionError(f"Mean mismatch for {column}")
        if round(float(folds[column].std(ddof=1)), 3) != round(float(sd[column]), 3):
            raise AssertionError(f"Sample SD mismatch for {column}")
    if not float(mean["ci_low"]) <= float(mean["macro_f1"]) <= float(mean["ci_high"]):
        raise AssertionError("Macro-F1 confidence interval does not contain the mean")


def verify_reference_records() -> None:
    provenance = json.loads((REFERENCE / "provenance.json").read_text(encoding="utf-8"))
    if provenance["execution_verified"] is not False:
        raise AssertionError("Reference provenance status must remain false")
    for path in REFERENCE.glob("*.csv"):
        frame = pd.read_csv(path)
        if "execution_verified" in frame and frame["execution_verified"].astype(str).str.lower().ne("false").any():
            raise AssertionError(f"Reference status changed in {path.name}")
    external = pd.read_csv(REFERENCE / "external_validation.csv")
    proposed = external[external["model"] == "PEND-CalNet"].set_index("dataset")
    assert np.isclose(proposed.loc["SLR149", "macro_f1"], 0.842)
    assert np.isclose(proposed.loc["Finance", "macro_f1"], 0.794)
    tests = pd.read_csv(REFERENCE / "statistical_tests.csv")
    if (tests["p_holm"] + 1e-12 < tests["p_raw"]).any():
        raise AssertionError("Holm-adjusted p-values must not be smaller than raw p-values")
    if ((tests["difference"] < tests["ci_low"]) | (tests["difference"] > tests["ci_high"])).any():
        raise AssertionError("A paired difference lies outside its interval")


def verify_anonymity() -> None:
    email_pattern = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix in {".png", ".jpg", ".jpeg", ".pt", ".pyc"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        unix_local = "/" + "workspace" + "/"
        windows_local = "C:" + "\\" + "Users" + "\\"
        if unix_local in text or windows_local in text:
            raise AssertionError(f"Local absolute path found in {path.relative_to(ROOT)}")
        if email_pattern.search(text):
            raise AssertionError(f"Email address found in {path.relative_to(ROOT)}")


def main() -> None:
    require_paths()
    verify_config()
    verify_fold_arithmetic()
    verify_reference_records()
    verify_anonymity()
    print("package verification passed")


if __name__ == "__main__":
    main()
