#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import torch

from pend_calnet.audio import acoustic_tracks, quality_descriptors
from pend_calnet.config import load_config
from pend_calnet.training import NormalizationState, build_model


def main() -> None:
    parser = argparse.ArgumentParser(description="Profile model parameters, latency, memory, and operator FLOPs")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--output", type=Path, default=Path("artifacts/profiling/model_profile.json"))
    args = parser.parse_args()
    config = load_config(args.config)
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    resolved_config = checkpoint.get("resolved_config", config)
    device = torch.device(args.device)
    model = build_model(resolved_config, checkpoint["speaker_count"], checkpoint["prompt_count"], checkpoint["variant"]).to(device)
    model.load_state_dict(checkpoint["model_state"])
    model.eval()
    normalization = NormalizationState.from_state_dict(checkpoint["normalization"])
    width = int(config["data"]["sample_rate"] * config["data"]["window_seconds"])
    waveform = torch.zeros(1, width)
    mask = torch.ones(1, width, dtype=torch.long)
    cues = acoustic_tracks(waveform[0], int(config["data"]["sample_rate"])).unsqueeze(0)
    quality = quality_descriptors(waveform[0], int(config["data"]["sample_rate"])).unsqueeze(0)
    cues = (cues - normalization.track_mean) / normalization.track_std
    quality = (quality - normalization.quality_mean) / normalization.quality_std
    inputs = [value.to(device) for value in [waveform, mask, cues, quality]]
    warmup = int(config["profiling"]["warmup_utterances"])
    repetitions = int(config["profiling"]["timed_utterances"])
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    with torch.no_grad():
        for _ in range(warmup):
            model(*inputs)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        elapsed = []
        for _ in range(repetitions):
            start = time.perf_counter()
            model(*inputs)
            if device.type == "cuda":
                torch.cuda.synchronize(device)
            elapsed.append((time.perf_counter() - start) * 1000.0)
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU], with_flops=True) as profile:
        with torch.no_grad():
            model(*inputs)
    flops = sum(event.flops for event in profile.key_averages() if event.flops is not None)
    total = sum(parameter.numel() for parameter in model.parameters())
    trainable = sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
    result = {
        "total_parameters_m": total / 1e6,
        "trainable_parameters_m": trainable / 1e6,
        "operator_flops_g": flops / 1e9,
        "latency_ms_mean": float(torch.tensor(elapsed).mean()),
        "latency_ms_sd": float(torch.tensor(elapsed).std(unbiased=True)),
        "peak_memory_gb": torch.cuda.max_memory_allocated(device) / 1e9 if device.type == "cuda" else None,
        "device": str(device),
        "repetitions": repetitions,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
