#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from pend_calnet.config import load_config
from pend_calnet.reporting import (
    plot_ablation,
    plot_baselines,
    plot_calibration_robustness,
    plot_external,
    plot_fold_performance,
    plot_statistics_interpretability,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build manuscript result graphics from tabular records")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--source", choices=["reference", "reproduced"], default="reference")
    args = parser.parse_args()
    config = load_config(args.config)
    source = Path("results/reference_records") if args.source == "reference" else Path(config["project"]["output_root"]) / "analysis"
    output = Path(config["project"]["output_root"]) / "report_assets"
    output.mkdir(parents=True, exist_ok=True)
    plot_fold_performance(pd.read_csv(source / "fold_metrics.csv"), output / "figure_3_fold_performance.png")
    plot_baselines(pd.read_csv(source / "baseline_metrics.csv"), output / "figure_4_baseline_comparison.png")
    plot_external(pd.read_csv(source / "external_validation.csv"), output / "figure_5_external_validation.png")
    plot_ablation(pd.read_csv(source / "ablation_metrics.csv"), output / "figure_6_ablation.png")
    plot_calibration_robustness(
        pd.read_csv(source / "calibration.csv"),
        pd.read_csv(source / "robustness.csv"),
        output / "figure_7_calibration_robustness.png",
    )
    plot_statistics_interpretability(
        pd.read_csv(source / "statistical_tests.csv"),
        pd.read_csv(source / "auxiliary_analysis.csv"),
        output / "figure_8_statistics_interpretability.png",
    )
    print(output.as_posix())


if __name__ == "__main__":
    main()
