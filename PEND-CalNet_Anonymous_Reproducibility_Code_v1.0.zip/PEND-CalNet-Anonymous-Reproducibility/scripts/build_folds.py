#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from pend_calnet.config import load_config
from pend_calnet.data import assign_outer_folds, read_manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Create speaker-grouped outer-fold assignments")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--output", type=Path, default=Path("manifests/tibmd_folds.csv"))
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()
    config = load_config(args.config)
    frame = read_manifest(config["data"]["development_manifest"])
    assigned = assign_outer_folds(frame, int(config["data"]["outer_folds"]), args.seed)
    for fold in range(1, int(config["data"]["outer_folds"]) + 1):
        train_speakers = set(assigned.loc[assigned["outer_fold"] != fold, "speaker_id"])
        test_speakers = set(assigned.loc[assigned["outer_fold"] == fold, "speaker_id"])
        if train_speakers & test_speakers:
            raise RuntimeError(f"Speaker overlap detected in fold {fold}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    assigned.to_csv(args.output, index=False)
    print(assigned.groupby(["outer_fold", "label"]).size().unstack(fill_value=0).to_string())


if __name__ == "__main__":
    main()
