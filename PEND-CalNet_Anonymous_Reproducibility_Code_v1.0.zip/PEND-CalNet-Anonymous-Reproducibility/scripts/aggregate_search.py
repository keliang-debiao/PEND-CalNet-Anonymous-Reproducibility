#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path


def mean_best_rank(records: list[dict], key: str, candidate) -> float:
    ranks = []
    for record in records:
        completed = [trial for trial in record["trials"] if trial["value"] is not None]
        ordered = sorted(completed, key=lambda trial: float(trial["value"]), reverse=True)
        matching = [index + 1 for index, trial in enumerate(ordered) if trial["params"].get(key) == candidate]
        ranks.append(min(matching) if matching else len(ordered) + 1)
    return sum(ranks) / len(ranks)


def main() -> None:
    parser = argparse.ArgumentParser(description="Aggregate fold-winning settings by source-only modal consensus")
    parser.add_argument("--inputs", required=True, nargs="+", type=Path)
    parser.add_argument("--output", type=Path, default=Path("artifacts/search/consensus.json"))
    args = parser.parse_args()
    records = [json.loads(path.read_text(encoding="utf-8")) for path in args.inputs]
    keys = sorted(records[0]["best_params"])
    consensus = {}
    for key in keys:
        values = [record["best_params"][key] for record in records]
        counts = Counter(values)
        maximum = max(counts.values())
        tied = [value for value, count in counts.items() if count == maximum]
        consensus[key] = min(tied, key=lambda value: (mean_best_rank(records, key, value), float(value)))
    payload = {
        "best_params": consensus,
        "fold_winners": [record["best_params"] for record in records],
        "tie_rule": "better mean inner-validation rank followed by the lower-complexity numeric value after a modal tie",
        "external_data_accessed": False,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(args.output.as_posix())


if __name__ == "__main__":
    main()
