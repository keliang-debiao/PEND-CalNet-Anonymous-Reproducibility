#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from pend_calnet.config import load_config
from pend_calnet.metrics import classification_metrics, mean_sd_t_ci


def ensemble_seed_predictions(paths: list[Path]) -> pd.DataFrame:
    frames = [pd.read_csv(path).sort_values("record_id").reset_index(drop=True) for path in paths]
    identifiers = frames[0]["record_id"]
    if any(not identifiers.equals(frame["record_id"]) for frame in frames[1:]):
        raise ValueError("Prediction records differ across seeds")
    columns = ["prob_u_tsang", "prob_amdo", "prob_kham"]
    probabilities = np.mean(np.stack([frame[columns].to_numpy() for frame in frames]), axis=0)
    return pd.DataFrame(
        {
            "record_id": identifiers,
            "label": frames[0]["label"],
            "predicted": probabilities.argmax(axis=1),
            **{column: probabilities[:, index] for index, column in enumerate(columns)},
        }
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Aggregate prediction-level outputs into analysis tables")
    parser.add_argument("--config", required=True, type=Path)
    args = parser.parse_args()
    config = load_config(args.config)
    root = Path(config["project"]["output_root"])
    rows = []
    for fold in range(1, int(config["data"]["outer_folds"]) + 1):
        paths = [root / "cv" / f"fold_{fold}" / f"seed_{seed}" / "predictions.csv" for seed in config["project"]["seeds"]]
        missing = [str(path) for path in paths if not path.is_file()]
        if missing:
            raise FileNotFoundError("Missing prediction files: " + ", ".join(missing))
        prediction = ensemble_seed_predictions(paths)
        probabilities = prediction[["prob_u_tsang", "prob_amdo", "prob_kham"]].to_numpy()
        metrics = classification_metrics(probabilities, prediction["label"].to_numpy()).as_dict()
        rows.append({"scope": "fold", "fold": fold, **metrics})
        output = root / "analysis" / "ensemble_predictions"
        output.mkdir(parents=True, exist_ok=True)
        prediction.to_csv(output / f"fold_{fold}.csv", index=False)
    frame = pd.DataFrame(rows)
    summary = {"scope": "mean", "fold": np.nan}
    deviation = {"scope": "sd", "fold": np.nan}
    intervals = {}
    for column in ["macro_f1", "uar", "accuracy", "macro_auroc", "ece", "brier"]:
        mean, sd, low, high = mean_sd_t_ci(frame[column].to_numpy())
        summary[column] = mean
        deviation[column] = sd
        intervals[column] = {"low": low, "high": high}
    output = root / "analysis"
    output.mkdir(parents=True, exist_ok=True)
    pd.concat([frame, pd.DataFrame([summary, deviation])], ignore_index=True).to_csv(output / "fold_metrics.csv", index=False)
    (output / "fold_intervals.json").write_text(json.dumps(intervals, indent=2, sort_keys=True), encoding="utf-8")
    print((output / "fold_metrics.csv").as_posix())


if __name__ == "__main__":
    main()
