#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description="Execute component-wise source ablations")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--fold", type=int, choices=range(1, 6))
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    variants = sorted(Path("configs/variants").glob("*.yaml"))
    folds = [args.fold] if args.fold else list(range(1, 6))
    for variant in variants:
        for fold in folds:
            command = [
                sys.executable,
                "scripts/train_cv.py",
                "--config",
                str(args.config),
                "--fold",
                str(fold),
                "--seed",
                str(args.seed),
                "--variant",
                str(variant),
                "--device",
                args.device,
            ]
            subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
