#!/usr/bin/env bash
set -euo pipefail

mode="${1:-all}"
device="${DEVICE:-cuda}"
config="configs/pend_calnet.yaml"
seeds=(2026 2027 2028)

python scripts/audit_data.py --config "$config"
python scripts/build_folds.py --config "$config"

if [[ "$mode" == "search" || "$mode" == "all" ]]; then
  for fold in 1 2 3 4 5; do
    python scripts/search_hyperparameters.py --config "$config" --fold "$fold" --device "$device"
  done
  python scripts/aggregate_search.py --inputs artifacts/search/fold_1.json artifacts/search/fold_2.json artifacts/search/fold_3.json artifacts/search/fold_4.json artifacts/search/fold_5.json
fi

if [[ "$mode" == "cv" || "$mode" == "all" ]]; then
  for fold in 1 2 3 4 5; do
    search_file="artifacts/search/fold_${fold}.json"
    search_args=()
    if [[ -f "$search_file" ]]; then
      search_args=(--search-result "$search_file")
    fi
    for seed in "${seeds[@]}"; do
      python scripts/train_cv.py --config "$config" --fold "$fold" --seed "$seed" --device "$device" "${search_args[@]}"
    done
  done
  python scripts/run_analyses.py --config "$config"
fi

if [[ "$mode" == "final" || "$mode" == "all" ]]; then
  consensus_args=()
  if [[ -f artifacts/search/consensus.json ]]; then
    consensus_args=(--search-result artifacts/search/consensus.json)
  fi
  for seed in "${seeds[@]}"; do
    python scripts/fit_final.py --config "$config" --seed "$seed" --device "$device" "${consensus_args[@]}"
  done
fi

if [[ "$mode" == "external" || "$mode" == "all" ]]; then
  checkpoints=(artifacts/final/seed_2026/checkpoint.pt artifacts/final/seed_2027/checkpoint.pt artifacts/final/seed_2028/checkpoint.pt)
  python scripts/evaluate_external.py --config "$config" --dataset slr149 --checkpoints "${checkpoints[@]}" --device "$device"
  python scripts/evaluate_external.py --config "$config" --dataset finance --checkpoints "${checkpoints[@]}" --device "$device"
  python scripts/run_robustness.py --config "$config" --dataset slr149 --checkpoints "${checkpoints[@]}" --device "$device"
fi

python scripts/verify_package.py
