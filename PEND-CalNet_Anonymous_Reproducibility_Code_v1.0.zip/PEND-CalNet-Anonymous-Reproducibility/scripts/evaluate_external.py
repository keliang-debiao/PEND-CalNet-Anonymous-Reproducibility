#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import yaml

from pend_calnet.calibration import SourceMoments, apply_calibrator
from pend_calnet.config import load_config
from pend_calnet.metrics import classification_metrics
from pend_calnet.model import MarginQualityAdaptiveCalibrator
from pend_calnet.statistics import cluster_bootstrap_interval, dialect_stratified_bootstrap_interval
from pend_calnet.training import NormalizationState, build_model, predict_sliding_windows


def macro_f1(probabilities: np.ndarray, labels: np.ndarray) -> float:
    from sklearn.metrics import f1_score

    return float(f1_score(labels, probabilities.argmax(axis=1), average="macro"))


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate frozen source checkpoints on one external corpus")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--dataset", required=True, choices=["slr149", "finance"])
    parser.add_argument("--checkpoints", required=True, nargs="+", type=Path)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    config = load_config(args.config)
    frame = pd.read_csv(config["data"]["external_manifests"][args.dataset])
    device = torch.device(args.device)
    all_probabilities = []
    seed_metrics = []
    labels = None
    for checkpoint_path in args.checkpoints:
        checkpoint = torch.load(checkpoint_path, map_location="cpu")
        resolved_config = checkpoint.get("resolved_config", config)
        variant = checkpoint["variant"]
        model = build_model(resolved_config, checkpoint["speaker_count"], checkpoint["prompt_count"], variant).to(device)
        model.load_state_dict(checkpoint["model_state"])
        normalization = NormalizationState.from_state_dict(checkpoint["normalization"])
        outputs = predict_sliding_windows(model, frame, normalization, resolved_config, device)
        moments = SourceMoments.from_state_dict(checkpoint["source_moments"])
        calibration_quality = moments.transform(outputs["representation"], outputs["quality"])
        calibrator = MarginQualityAdaptiveCalibrator(
            quality_size=calibration_quality.shape[1],
            hidden_size=int(config["calibration"]["hidden_size"]),
            temperature_min=float(config["calibration"]["temperature_min"]),
        ).to(device)
        calibrator.load_state_dict(checkpoint["calibrator_state"])
        probabilities, _ = apply_calibrator(calibrator, outputs["logits"], calibration_quality, device)
        all_probabilities.append(probabilities)
        labels = outputs["labels"]
        seed_metrics.append(classification_metrics(probabilities, labels, bins=int(config["calibration"]["hard_ece_bins"])).as_dict())
    probabilities = np.mean(np.stack(all_probabilities), axis=0)
    assert labels is not None
    metrics = classification_metrics(probabilities, labels, bins=int(config["calibration"]["hard_ece_bins"])).as_dict()
    replicates = int(config["statistics"]["bootstrap_replicates"])
    if args.dataset == "finance" or (frame["speaker_id"].fillna("").astype(str).str.len() == 0).any():
        low, high = dialect_stratified_bootstrap_interval(probabilities, labels, macro_f1, replicates=replicates)
        resampling_unit = "dialect_stratified_utterance"
    else:
        low, high = cluster_bootstrap_interval(
            probabilities,
            labels,
            frame["speaker_id"].astype(str).to_numpy(),
            macro_f1,
            replicates=replicates,
        )
        resampling_unit = "speaker"
    metrics["macro_f1_ci_low"] = low
    metrics["macro_f1_ci_high"] = high
    metrics["resampling_unit"] = resampling_unit
    for key in ["macro_f1", "uar", "accuracy", "macro_auroc", "ece", "brier"]:
        values = np.asarray([record[key] for record in seed_metrics], dtype=np.float64)
        metrics[f"seed_{key}_mean"] = float(values.mean())
        metrics[f"seed_{key}_sd"] = float(values.std(ddof=1)) if len(values) > 1 else 0.0
    destination = Path(config["project"]["output_root"]) / "external" / args.dataset
    destination.mkdir(parents=True, exist_ok=True)
    prediction = pd.DataFrame(
        {
            "record_id": frame["record_id"],
            "label": labels,
            "predicted": probabilities.argmax(axis=1),
            "prob_u_tsang": probabilities[:, 0],
            "prob_amdo": probabilities[:, 1],
            "prob_kham": probabilities[:, 2],
        }
    )
    prediction.to_csv(destination / "ensemble_predictions.csv", index=False)
    (destination / "metrics.json").write_text(json.dumps(metrics, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(metrics, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
