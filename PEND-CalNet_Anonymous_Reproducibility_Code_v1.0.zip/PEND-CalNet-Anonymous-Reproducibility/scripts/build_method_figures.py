#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch


def box(axis, x: float, y: float, width: float, height: float, label: str, color: str) -> None:
    axis.add_patch(FancyBboxPatch((x, y), width, height, boxstyle="round,pad=0.02", facecolor=color, edgecolor="#203040"))
    axis.text(x + width / 2, y + height / 2, label, ha="center", va="center", fontsize=8)


def arrow(axis, start: tuple[float, float], end: tuple[float, float]) -> None:
    axis.add_patch(FancyArrowPatch(start, end, arrowstyle="->", mutation_scale=12, color="#203040"))


def workflow(output: Path) -> None:
    figure, axis = plt.subplots(figsize=(11, 4.8))
    axis.set_xlim(0, 11)
    axis.set_ylim(0, 5)
    axis.axis("off")
    labels = [
        "Public corpus\nacquisition", "Audit and\ngroup control", "Fold-specific\npreprocessing",
        "Model development\nand inner selection", "Frozen external\nvalidation",
    ]
    for index, label in enumerate(labels):
        x = 0.3 + index * 2.15
        box(axis, x, 3.0, 1.65, 0.8, label, "#DCEAF6")
        if index:
            arrow(axis, (x - 0.45, 3.4), (x, 3.4))
    lower = ["Grouped five-fold CV", "Source-only MQAC", "Statistics and calibration", "Robustness and interpretation"]
    for index, label in enumerate(lower):
        x = 1.0 + index * 2.5
        box(axis, x, 1.2, 1.9, 0.7, label, "#E8F2E3")
        if index:
            arrow(axis, (x - 0.55, 1.55), (x, 1.55))
    arrow(axis, (5.5, 3.0), (5.5, 1.9))
    figure.tight_layout()
    figure.savefig(output, dpi=300, bbox_inches="tight")
    plt.close(figure)


def architecture(output: Path) -> None:
    figure, axis = plt.subplots(figsize=(11, 5.5))
    axis.set_xlim(0, 11)
    axis.set_ylim(0, 6)
    axis.axis("off")
    top = ["Waveform", "XLS-R + LoRA", "Phonological\nevidence fusion", "Quality-aware\nstatistics pooling", "Dialect logits"]
    for index, label in enumerate(top):
        x = 0.25 + index * 2.15
        box(axis, x, 4.2, 1.7, 0.75, label, "#DCEAF6")
        if index:
            arrow(axis, (x - 0.45, 4.575), (x, 4.575))
    box(axis, 4.55, 2.55, 1.9, 0.7, "Dialect representation", "#E8F2E3")
    box(axis, 1.55, 1.0, 2.0, 0.7, "Counterfactual pitch loss", "#F7E3D5")
    box(axis, 4.5, 1.0, 2.0, 0.7, "Nuisance adversaries", "#F7E3D5")
    box(axis, 7.45, 1.0, 2.0, 0.7, "Contrastive consistency", "#F7E3D5")
    box(axis, 8.65, 2.55, 1.9, 0.7, "MQAC probabilities", "#E8F2E3")
    arrow(axis, (5.5, 4.2), (5.5, 3.25))
    arrow(axis, (5.5, 2.55), (2.55, 1.7))
    arrow(axis, (5.5, 2.55), (5.5, 1.7))
    arrow(axis, (5.5, 2.55), (8.45, 1.7))
    arrow(axis, (9.7, 4.2), (9.6, 3.25))
    figure.tight_layout()
    figure.savefig(output, dpi=300, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    output = Path("artifacts/report_assets")
    output.mkdir(parents=True, exist_ok=True)
    workflow(output / "figure_1_workflow.png")
    architecture(output / "figure_2_architecture.png")
    print(output.as_posix())


if __name__ == "__main__":
    main()
