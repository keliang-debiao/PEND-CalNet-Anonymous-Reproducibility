#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import optuna
import pandas as pd
import torch
import yaml

from pend_calnet.config import load_config, seed_everything
from pend_calnet.data import split_outer_training_groups
from pend_calnet.workflow import score_source_candidate


def main() -> None:
    parser = argparse.ArgumentParser(description="Run source-only nested hyperparameter selection")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--fold", required=True, type=int, choices=range(1, 6))
    parser.add_argument("--folds", type=Path, default=Path("manifests/tibmd_folds.csv"))
    parser.add_argument("--variant", type=Path, default=Path("configs/variants/full.yaml"))
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    base = load_config(args.config)
    variant = yaml.safe_load(args.variant.read_text(encoding="utf-8"))
    seed = int(base["search"]["sampler_seeds"][args.fold - 1])
    seed_everything(seed)
    frame = pd.read_csv(args.folds)
    partitions = split_outer_training_groups(
        frame,
        args.fold,
        float(base["data"]["inner_group_fraction"]),
        float(base["data"]["calibration_group_fraction"]),
        seed,
    )
    space = base["search"]["space"]

    def objective(trial: optuna.Trial) -> float:
        config = copy.deepcopy(base)
        config["encoder"]["lora"]["rank"] = trial.suggest_categorical("lora_rank", space["lora_rank"])
        for key in ["encoder_lora_lr", "new_layer_lr"]:
            config["optimization"][key] = trial.suggest_categorical(key, space[key])
        config["model"]["feature_dropout"] = trial.suggest_categorical("feature_dropout", space["feature_dropout"])
        for key in ["phonological_evidence", "nuisance_disentanglement", "supervised_contrastive", "augmentation_consistency"]:
            config["loss"][key] = trial.suggest_categorical(key, space[key])
        config["loss"]["contrastive_temperature"] = trial.suggest_categorical(
            "contrastive_temperature", space["contrastive_temperature"]
        )
        return score_source_candidate(
            config,
            variant,
            partitions,
            seed=seed + trial.number,
            batch_size=args.batch_size,
            workers=args.workers,
            device=torch.device(args.device),
        )

    sampler = optuna.samplers.TPESampler(seed=seed, n_startup_trials=int(base["search"]["startup_trials"]), multivariate=True)
    study = optuna.create_study(direction="maximize", sampler=sampler)
    study.optimize(objective, n_trials=int(base["search"]["trials_per_fold"]))
    output = args.output or Path(f"artifacts/search/fold_{args.fold}.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(
            {
                "fold": args.fold,
                "best_value": study.best_value,
                "best_params": study.best_params,
                "trials": [
                    {"number": trial.number, "value": trial.value, "params": trial.params, "state": trial.state.name}
                    for trial in study.trials
                ],
            },
            indent=2,
            sort_keys=True,
        ),
        encoding="utf-8",
    )
    print(f"wrote={output} best_macro_f1={study.best_value:.6f}")


if __name__ == "__main__":
    main()
