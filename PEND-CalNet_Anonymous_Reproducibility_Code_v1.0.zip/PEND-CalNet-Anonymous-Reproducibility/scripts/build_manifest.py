#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import re
from pathlib import Path

import pandas as pd
import soundfile as sf
import yaml


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a corpus manifest from a released directory")
    parser.add_argument("--dataset", required=True, type=Path)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def file_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def normalized_label(path: Path, aliases: dict[str, list[str]]) -> str:
    normalized_path = path.as_posix().lower().replace("-", "_")
    tokens = set(re.split(r"[^a-z0-9]+", normalized_path))
    tokens.update(part.lower().replace("-", "_") for part in path.parts)
    token_text = re.sub(r"[^a-z0-9]+", " ", normalized_path.replace("_", " "))
    for canonical, values in aliases.items():
        accepted = {canonical.lower().replace("-", "_")} | {
            value.lower().replace("-", "_") for value in values
        }
        if tokens & accepted or any(re.search(rf"\b{re.escape(value.replace('_', ' '))}\b", token_text) for value in accepted):
            return canonical
    raise ValueError(f"Could not infer a dialect label from path: {path}")


def metadata_table(root: Path, candidates: list[str]) -> pd.DataFrame | None:
    for name in candidates:
        path = root / name
        if path.is_file() and path.suffix.lower() == ".csv":
            return pd.read_csv(path)
    return None


def first_column(frame: pd.DataFrame, candidates: list[str]) -> str | None:
    lowered = {str(column).lower(): str(column) for column in frame.columns}
    for candidate in candidates:
        if candidate.lower() in lowered:
            return lowered[candidate.lower()]
    return None


def main() -> None:
    args = parse_args()
    config = yaml.safe_load(args.dataset.read_text(encoding="utf-8"))
    root = args.root.expanduser().resolve()
    audio_files = sorted({path.resolve() for pattern in config["audio_globs"] for path in root.glob(pattern)})
    if not audio_files:
        raise FileNotFoundError(f"No audio files found beneath {root}")
    metadata = metadata_table(root, config["metadata_candidates"])
    lookup: dict[str, pd.Series] = {}
    columns: dict[str, str | None] = {}
    if metadata is not None:
        columns = {
            "path": first_column(metadata, config["path_column_candidates"]),
            "label": first_column(metadata, config["label_column_candidates"]),
            "speaker": first_column(metadata, config["speaker_column_candidates"]),
            "prompt": first_column(metadata, config["prompt_column_candidates"]),
        }
        if columns["path"]:
            for _, row in metadata.iterrows():
                token = Path(str(row[columns["path"]])).stem
                lookup[token] = row
    rows = []
    for audio_path in audio_files:
        row = lookup.get(audio_path.stem)
        label = str(row[columns["label"]]) if row is not None and columns.get("label") else normalized_label(audio_path.relative_to(root), config["label_aliases"])
        if row is not None and columns.get("speaker"):
            speaker = str(row[columns["speaker"]])
        elif config.get("speaker_from_parent_depth") is not None:
            speaker = audio_path.parents[int(config["speaker_from_parent_depth"]) - 1].name
        else:
            speaker = ""
        if row is not None and columns.get("prompt"):
            prompt = str(row[columns["prompt"]])
        else:
            pieces = audio_path.stem.split(config["prompt_from_stem_delimiter"])
            prompt = pieces[int(config["prompt_from_stem_index"])]
        info = sf.info(audio_path)
        relative = audio_path.relative_to(root).as_posix()
        record_id = f"{config['corpus_id']}:{relative}"
        rows.append(
            {
                "record_id": record_id,
                "corpus": config["corpus_id"],
                "audio_path": str(audio_path),
                "label": label,
                "speaker_id": speaker,
                "prompt_id": prompt,
                "duration_seconds": info.frames / float(info.samplerate),
                "sample_rate": info.samplerate,
                "sha256": file_digest(audio_path),
            }
        )
    output = pd.DataFrame(rows).sort_values("record_id")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    output.to_csv(args.output, index=False)
    print(f"wrote={args.output} rows={len(output)}")


if __name__ == "__main__":
    main()
