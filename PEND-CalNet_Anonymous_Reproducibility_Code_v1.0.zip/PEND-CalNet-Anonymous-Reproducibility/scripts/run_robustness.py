#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import f1_score

from pend_calnet.calibration import SourceMoments, apply_calibrator
from pend_calnet.config import load_config
from pend_calnet.metrics import classification_metrics
from pend_calnet.model import MarginQualityAdaptiveCalibrator
from pend_calnet.robustness import deterministic_track_dropout, perturb_waveform
from pend_calnet.statistics import cluster_bootstrap_interval, dialect_stratified_bootstrap_interval
from pend_calnet.training import NormalizationState, build_model, predict_sliding_windows


def macro_f1(probabilities: np.ndarray, labels: np.ndarray) -> float:
    return float(f1_score(labels, probabilities.argmax(axis=1), average="macro"))


def conditions(config: dict) -> list[tuple[str, object, object]]:
    rows: list[tuple[str, object, object]] = [("clean", None, None)]
    for level in config["robustness"]["noise_snr_db"]:
        rows.append(
            (
                f"noise_{level}db",
                lambda waveform, row, level=level: perturb_waveform(waveform, str(row.record_id), noise_snr_db=float(level)),
                None,
            )
        )
    for fraction in config["robustness"]["pitch_flatten_fraction"]:
        rows.append(
            (
                f"pitch_flattening_{fraction}",
                lambda waveform, row, fraction=fraction: perturb_waveform(
                    waveform, str(row.record_id), pitch_flatten_fraction=float(fraction)
                ),
                None,
            )
        )
    for fraction in config["robustness"]["acoustic_track_dropout"]:
        rows.append(
            (
                f"track_dropout_{fraction}",
                None,
                lambda tracks, row, fraction=fraction: deterministic_track_dropout(tracks, float(fraction), str(row.record_id)),
            )
        )
    seconds = float(config["robustness"]["clip_seconds"])
    width = int(round(seconds * int(config["data"]["sample_rate"])))
    rows.append((f"clip_{seconds}s", lambda waveform, row: waveform[:width], None))
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description="Run prespecified inference-time stress tests")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--dataset", choices=["slr149", "finance"], default="slr149")
    parser.add_argument("--checkpoints", required=True, nargs="+", type=Path)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    config = load_config(args.config)
    frame = pd.read_csv(config["data"]["external_manifests"][args.dataset])
    device = torch.device(args.device)
    result_rows = []
    for condition, waveform_transform, cue_transform in conditions(config):
        seed_probabilities = []
        labels = None
        for checkpoint_path in args.checkpoints:
            checkpoint = torch.load(checkpoint_path, map_location="cpu")
            resolved_config = checkpoint.get("resolved_config", config)
            model = build_model(
                resolved_config,
                checkpoint["speaker_count"],
                checkpoint["prompt_count"],
                checkpoint["variant"],
            ).to(device)
            model.load_state_dict(checkpoint["model_state"])
            normalization = NormalizationState.from_state_dict(checkpoint["normalization"])
            output = predict_sliding_windows(
                model,
                frame,
                normalization,
                resolved_config,
                device,
                waveform_transform=waveform_transform,
                cue_transform=cue_transform,
            )
            moments = SourceMoments.from_state_dict(checkpoint["source_moments"])
            quality = moments.transform(output["representation"], output["quality"])
            calibrator = MarginQualityAdaptiveCalibrator(
                quality_size=quality.shape[1],
                hidden_size=int(config["calibration"]["hidden_size"]),
                temperature_min=float(config["calibration"]["temperature_min"]),
            ).to(device)
            calibrator.load_state_dict(checkpoint["calibrator_state"])
            probabilities, _ = apply_calibrator(calibrator, output["logits"], quality, device)
            seed_probabilities.append(probabilities)
            labels = output["labels"]
        probabilities = np.mean(np.stack(seed_probabilities), axis=0)
        metric = classification_metrics(probabilities, labels, bins=int(config["calibration"]["hard_ece_bins"]))
        if args.dataset == "finance" or (frame["speaker_id"].fillna("").astype(str).str.len() == 0).any():
            low, high = dialect_stratified_bootstrap_interval(
                probabilities,
                labels,
                macro_f1,
                replicates=int(config["statistics"]["bootstrap_replicates"]),
            )
        else:
            low, high = cluster_bootstrap_interval(
                probabilities,
                labels,
                frame["speaker_id"].astype(str).to_numpy(),
                macro_f1,
                replicates=int(config["statistics"]["bootstrap_replicates"]),
            )
        result_rows.append({"condition": condition, **metric.as_dict(), "ci_low": low, "ci_high": high})
    destination = Path(config["project"]["output_root"]) / "robustness"
    destination.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(result_rows).to_csv(destination / f"{args.dataset}.csv", index=False)
    print(json.dumps(result_rows, indent=2))


if __name__ == "__main__":
    main()
