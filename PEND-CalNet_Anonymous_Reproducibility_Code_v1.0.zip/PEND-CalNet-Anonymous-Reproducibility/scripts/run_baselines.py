#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import opensmile
import pandas as pd
import torch
import yaml
from sklearn.neural_network import MLPClassifier

from pend_calnet.baselines import BaselineSpec, fit_baseline, traditional_baselines
from pend_calnet.config import load_config, seed_everything
from pend_calnet.data import split_outer_training_groups
from pend_calnet.metrics import classification_metrics
from pend_calnet.neural_baselines import build_audio_baseline, fit_audio_baseline, fit_temperature, predict_audio_baseline
from pend_calnet.training import class_balancing_weights, estimate_normalization, make_dataset, make_loader


def extract_egemaps(frame: pd.DataFrame, cache: Path) -> np.ndarray:
    if cache.is_file():
        stored = pd.read_csv(cache, index_col=0)
        if stored.index.astype(str).tolist() == frame["record_id"].astype(str).tolist():
            return stored.to_numpy(dtype=np.float32)
    smile = opensmile.Smile(
        feature_set=opensmile.FeatureSet.eGeMAPSv02,
        feature_level=opensmile.FeatureLevel.Functionals,
    )
    rows = [smile.process_file(path).iloc[0] for path in frame["audio_path"]]
    values = pd.DataFrame(rows, index=frame["record_id"].astype(str))
    cache.parent.mkdir(parents=True, exist_ok=True)
    values.to_csv(cache)
    return values.to_numpy(dtype=np.float32)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run one prespecified baseline on one outer fold")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--baseline-config", type=Path, default=Path("configs/baselines.yaml"))
    parser.add_argument("--model", required=True)
    parser.add_argument("--fold", required=True, type=int, choices=range(1, 6))
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--folds", type=Path, default=Path("manifests/tibmd_folds.csv"))
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    config = load_config(args.config)
    baseline_config = yaml.safe_load(args.baseline_config.read_text(encoding="utf-8"))
    seed_everything(args.seed)
    frame = pd.read_csv(args.folds)
    partitions = split_outer_training_groups(
        frame,
        args.fold,
        float(config["data"]["inner_group_fraction"]),
        float(config["data"]["calibration_group_fraction"]),
        args.seed,
    )
    destination = Path(config["project"]["output_root"]) / "baselines" / args.model / f"fold_{args.fold}"
    destination.mkdir(parents=True, exist_ok=True)
    labels = partitions["label"].map(config["project"]["class_to_index"]).to_numpy()
    traditional = {item.name: item for item in traditional_baselines(args.seed)}
    if args.model in traditional or args.model == "mlp":
        features = extract_egemaps(partitions, destination / "egemaps.csv")
        train_index = np.flatnonzero(partitions["partition"] == "stage1_train")
        test_index = np.flatnonzero(partitions["partition"] == "outer_test")
        if args.model == "mlp":
            spec = BaselineSpec(
                "mlp",
                MLPClassifier(hidden_layer_sizes=(256, 256), alpha=0.01, batch_size=256, max_iter=300, early_stopping=True, random_state=args.seed),
            )
        else:
            spec = traditional[args.model]
        fitted = fit_baseline(spec, features[train_index], labels[train_index])
        probabilities = fitted.predict_proba(features[test_index])
        test_labels = labels[test_index]
        identifiers = partitions.iloc[test_index]["record_id"].astype(str).tolist()
        best_epoch = None
    else:
        family = next((group for group in ["neural", "foundation"] if args.model in baseline_config[group]), None)
        if family is None:
            raise ValueError(f"Unknown baseline: {args.model}")
        source = partitions[partitions["partition"] == "stage1_train"]
        inner = partitions[partitions["partition"] == "inner_validation"]
        calibration = partitions[partitions["partition"] == "source_calibration"]
        test = partitions[partitions["partition"] == "outer_test"]
        normalization = estimate_normalization(source, config["project"]["class_to_index"], 16000, 4.0, args.seed)
        loaders = {
            name: make_loader(make_dataset(part, config, normalization, name == "source", args.seed), args.batch_size, name == "source", args.workers, args.seed)
            for name, part in {"source": source, "inner": inner, "calibration": calibration, "test": test}.items()
        }
        model = build_audio_baseline(args.model, baseline_config[family][args.model], 3)
        fitted = fit_audio_baseline(
            model,
            loaders["source"],
            loaders["inner"],
            class_balancing_weights(source, config["project"]["class_to_index"]),
            torch.device(args.device),
        )
        calibration_logits, calibration_labels, _ = predict_audio_baseline(model, loaders["calibration"], torch.device(args.device))
        temperature = fit_temperature(calibration_logits, calibration_labels, torch.device(args.device))
        test_logits, test_labels, identifiers = predict_audio_baseline(model, loaders["test"], torch.device(args.device))
        probabilities = torch.softmax(torch.from_numpy(test_logits) / temperature, dim=-1).numpy()
        best_epoch = fitted.best_epoch
    metrics = classification_metrics(probabilities, test_labels, bins=int(config["calibration"]["hard_ece_bins"])).as_dict()
    prediction = pd.DataFrame(
        {
            "record_id": identifiers,
            "label": test_labels,
            "predicted": probabilities.argmax(axis=1),
            "prob_u_tsang": probabilities[:, 0],
            "prob_amdo": probabilities[:, 1],
            "prob_kham": probabilities[:, 2],
        }
    )
    prediction.to_csv(destination / "predictions.csv", index=False)
    payload = {"model": args.model, "fold": args.fold, "seed": args.seed, "best_epoch": best_epoch, "metrics": metrics}
    (destination / "metrics.json").write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
