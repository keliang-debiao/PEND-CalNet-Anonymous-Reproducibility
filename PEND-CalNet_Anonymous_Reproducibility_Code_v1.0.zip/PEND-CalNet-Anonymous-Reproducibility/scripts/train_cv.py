#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch
import yaml

from pend_calnet.config import apply_selected_parameters, load_config, seed_everything
from pend_calnet.data import split_outer_training_groups
from pend_calnet.workflow import run_source_partition


def main() -> None:
    parser = argparse.ArgumentParser(description="Fit and evaluate one grouped outer fold")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--fold", required=True, type=int, choices=range(1, 6))
    parser.add_argument("--seed", required=True, type=int)
    parser.add_argument("--folds", type=Path, default=Path("manifests/tibmd_folds.csv"))
    parser.add_argument("--variant", type=Path, default=Path("configs/variants/full.yaml"))
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--search-result", type=Path)
    args = parser.parse_args()
    config = load_config(args.config)
    if args.search_result:
        selected = json.loads(args.search_result.read_text(encoding="utf-8"))["best_params"]
        config = apply_selected_parameters(config, selected)
    variant = yaml.safe_load(args.variant.read_text(encoding="utf-8"))
    seed_everything(args.seed)
    frame = pd.read_csv(args.folds)
    partitions = split_outer_training_groups(
        frame,
        args.fold,
        float(config["data"]["inner_group_fraction"]),
        float(config["data"]["calibration_group_fraction"]),
        args.seed,
    )
    destination = Path(config["project"]["output_root"]) / "cv" / f"fold_{args.fold}" / f"seed_{args.seed}"
    record = run_source_partition(
        config,
        variant,
        partitions,
        destination,
        args.seed,
        args.batch_size,
        args.workers,
        torch.device(args.device),
        "outer_test",
    )
    (destination / "split_assignments.csv").write_text(partitions.to_csv(index=False), encoding="utf-8")
    print(json.dumps(record, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
